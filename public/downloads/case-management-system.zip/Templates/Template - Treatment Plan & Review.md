# Treatment Plan & Periodic Review Note

**Client ID**: {{client_id}}  
**Client Initials**: {{initials}}  
**Document Type**: [ ] Initial Plan (Day 1-3)  [ ] 30-Day Review  [ ] 60-Day Review  [ ] 90-Day Review  [ ] Transition Plan  
**Current Level of Care**: [ ] PHP (Partial Hospitalization)  [ ] IOP (Intensive Outpatient)  
**Effective Date Range**: YYYY-MM-DD to YYYY-MM-DD  
**Primary Diagnosis**: [ICD-10 Code & Name]  
**Secondary Diagnosis**: [ICD-10 Code & Name]

---

## 🎯 The "Golden Thread" Problem, Goal & Objective Framework

### Problem 1: Substance Use / Relapse Vulnerability
* **Problem Statement**: Client experiences uncontrollable cravings and high relapse vulnerability to [Substance(s)] as evidenced by [history of overdose / loss of control / past relapses when unmonitored].
* **SMART Long-Term Goal**: Client will achieve and maintain continuous abstinence from illicit substances while enrolled in [PHP / IOP] as demonstrated by negative random toxicology screens and self-reported recovery coping mechanisms over the next 30 days.
* **Measurable Objective 1.1**: Client will attend [3 / 5] days of clinical programming per week and participate actively in group therapy sessions 80%+ of the time.
  - *Target Date*: YYYY-MM-DD | *Status*: [In Progress / Achieved / Modified]
* **Measurable Objective 1.2**: Client will identify at least 3 high-risk relapse triggers (e.g., specific people, negative emotional states, transit routes) and formulate a written Relapse Prevention Plan by [Date].
  - *Target Date*: YYYY-MM-DD | *Status*: [In Progress / Achieved / Modified]
* **Clinical Interventions**:
  - Clinician will provide evidence-based CBT / Relapse Prevention therapy 9–20 hours weekly.
  - Case manager will coordinate with OTP clinic regarding Methadone compliance and toxicology results weekly.

---

### Problem 2: Co-Occurring Mental Health / Emotional Dysregulation
* **Problem Statement**: Client experiences moderate-to-severe symptoms of [Depression / Anxiety / Trauma] as evidenced by [sleep disturbance, panic attacks, isolation, intrusive memories] hindering daily functioning.
* **SMART Long-Term Goal**: Client will reduce emotional distress and demonstrate at least 2 distress tolerance coping mechanisms daily without resorting to substance use.
* **Measurable Objective 2.1**: Client will practice and document one grounding technique (e.g., 5-4-3-2-1 sensory check or diaphragmatic breathing) during moments of heightened anxiety at least 4x/week.
  - *Target Date*: YYYY-MM-DD | *Status*: [In Progress / Achieved / Modified]
* **Clinical Interventions**:
  - Clinician will facilitate psychoeducational and skills groups focusing on DBT emotion regulation and mindfulness.
  - Case manager will liaise with psychiatric provider to monitor medication compliance and side effects.

---

### Problem 3: Social Determinants of Health / Case Management Needs
* **Problem Statement**: Client faces barriers in recovery maintenance due to unstable [Housing / Transportation / Financial Support / Primary Healthcare].
* **SMART Long-Term Goal**: Client will establish stable community and social supports to sustain step-down to a lower level of care.
* **Measurable Objective 3.1**: Client will complete Medi-Drive ride scheduling requirements and attend 100% of scheduled appointments without transit cancellations.
* **Measurable Objective 3.2**: Client will meet with Case Manager weekly to submit applications for [Sober Living / Housing Assistance / Medicaid renewal / Primary Care PCP intake].
  - *Target Date*: YYYY-MM-DD | *Status*: [In Progress / Achieved / Modified]

---

## 🔍 Periodic Review & Continued Stay Justification (For 30 / 60 / 90 Day Reviews)

### 1. Progress Towards Goals Since Last Review
* **Goal 1 Progress**: [e.g., Client has attended 92% of IOP groups over past 30 days. Toxicology screens negative for fentanyl and cocaine; stable on Methadone 85mg daily.]
* **Goal 2 Progress**: [e.g., Client actively engaged in DBT skills group, reported decrease in panic attacks from 4x/week to 1x/week.]
* **Barriers Encountered**: [e.g., Client had one late arrival due to NEMT driver delay; addressed with broker. Occasional sleep disturbance reported.]

### 2. Medical Necessity Justification for Continued Stay (ASAM Criteria)
* **Why can the client NOT be stepped down to regular outpatient (OP) at this time?**
  > "Client continues to meet ASAM Level [2.1 IOP / 2.5 PHP] criteria. In Dimension 5 (Relapse Potential), client continues to experience moderate cravings and has not yet established a resilient sober support network outside of treatment. In Dimension 6 (Recovery Environment), client's current living environment presents high relapse exposure. Stepping down to standard Outpatient (1-2 hrs/week) at this juncture carries a high risk of relapse and decompensation. Continued intensive structure is medically necessary to solidify recovery skills."

### 3. Plan Modifications & Discharge Prognosis
* [ ] Maintain current treatment plan goals and objectives.
* [ ] Modify Objective [X] to address [emerging trigger / newly identified barrier].
* **Estimated Step-Down / Discharge Date**: YYYY-MM-DD
* **Anticipated Step-Down Level of Care**: [ ] Outpatient Therapy (OP)  [ ] Peer Support / Recovery Community

---

## ✍️ Signatures & Approvals
* **Client Signature**: ___________________________ Date: YYYY-MM-DD
* **Case Manager / Primary Clinician**: ___________________________ Date: YYYY-MM-DD
* **Clinical Supervisor / Medical Director**: ___________________________ Date: YYYY-MM-DD
