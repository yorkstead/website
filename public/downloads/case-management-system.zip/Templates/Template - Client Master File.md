---
client_id: "C-XXXX"
initials: "XX"
status: "Active" # Active | Discharged | Pending Intake
level_of_care: "PHP" # PHP | IOP | OP
admission_date: YYYY-MM-DD
est_discharge_date: YYYY-MM-DD
primary_dx: "F10.20 (Alcohol Use Disorder, Severe)"
secondary_dx: "F33.1 (MDD, Recurrent, Moderate)"
payer: "Medicaid / Managed Care Name"
insurance_id: "XXXXXX"
auth_number: "AUTH-XXXXX"
auth_expiration_date: YYYY-MM-DD
tx_plan_due_date: YYYY-MM-DD
mat_status: "Active - Methadone" # None | Methadone | Suboxone | Vivitrol
mat_clinic: "Name of OTP / Clinic"
medi_drive_status: "Active Standing" # Active Standing | On Demand | Self-Transport | Inactive
---

# Client Profile: {{client_id}} ({{initials}})

## 📌 Core Snapshot
* **Date of Birth**: YYYY-MM-DD (Age: XX)
* **Phone**: (XXX) XXX-XXXX
* **Current Living Situation**: [Sober Living / Family Home / Shelter / Unhoused]
* **Address**: [Street, City, Zip, Gate Code]
* **Emergency Contact**: [Name, Relationship, Phone]
* **Assigned Primary Counselor / Therapist**: [Name]

---

## 🚌 Transportation / Medi-Drive Info
* **NEMT Broker**: [Modivcare / Veyo / SafeRide / County Health Transit]
* **Broker Member ID**: [Medicaid or Broker ID]
* **Standing Ride Days**: [ ] Mon  [ ] Tue  [ ] Wed  [ ] Thu  [ ] Fri
* **Pickup Window**: [e.g., 07:45 AM - 08:00 AM]
* **Trip Confirmation / Reservation #**: [XXXXXXXX]
* **Special Transit Needs**: [Wheelchair / Front Seat / Spanish Speaking / Curb-to-Curb]

---

## 💊 Medication-Assisted Treatment (MAT) / Methadone Coordination
* **OTP / Clinic Name**: [Clinic Name]
* **Dosing Nurse / Clinic Phone**: (XXX) XXX-XXXX ext. XX
* **OTP Counselor Name & Direct Line**: [Name] - (XXX) XXX-XXXX
* **Dosing Schedule & Dose**: [e.g., Methadone 85 mg daily, Window: 06:00 AM - 07:30 AM]
* **Take-Home Status**: [Daily dosing / Weekend take-home / Phase 1]
* **42 CFR Part 2 ROI Expiration Date**: YYYY-MM-DD
* **Last Toxicology Exchange Date**: YYYY-MM-DD

---

## 📋 Compliance & Regulatory Dates
* **Initial Assessment Completed**: YYYY-MM-DD
* **Initial Treatment Plan Completed**: YYYY-MM-DD
* **30-Day Tx Plan Review Due**: YYYY-MM-DD
* **60-Day Tx Plan Review Due**: YYYY-MM-DD
* **Current Insurance Authorization Expires**: YYYY-MM-DD
* **UR Concurrent Review Submission Window**: [2 business days prior to auth expiry]

---

## 📝 Case Management Quick Log
*(Log date, type: Transport, MAT, Housing, UR, Legal, and note)*

| Date | Category | Summary / Contact Person | Next Step / Follow-up |
| :--- | :--- | :--- | :--- |
| YYYY-MM-DD | Medi-Drive | Called dispatch re: late driver. Driver arrived 08:20. | Confirmed return ride is on schedule. |
| YYYY-MM-DD | MAT | Spoke with counselor [Name] at OTP. Faxed weekly attendance. | Next attendance exchange due Friday. |
| YYYY-MM-DD | UR Auth | Submitted 5-day concurrent review via portal. | Check approval by 3:00 PM tomorrow. |

---

## 🔗 Related Notes
* [[Templates/Template - Biopsychosocial Intake Checklist|Intake Assessment]]
* [[Templates/Template - Treatment Plan & Review|Current Treatment Plan]]
* [[Templates/Template - UR Concurrent Review Prep Sheet|Latest UR Concurrent Review]]
* [[Templates/Template - Continuity of Care & Discharge Plan|Discharge Planning]]
