# Utilization Review (UR) Concurrent Review Prep Sheet

> [!TIP]
> Have this sheet open when speaking with the insurance care manager or when typing into the provider portal (Availity, Carelon, Optum, Magellan, State Medicaid).

---

## 📞 Call & Auth Header
* **Client ID / Initials**: {{client_id}} ({{initials}})
* **Insurance Carrier / Plan**: [e.g., Aetna Better Health / UnitedHealthcare Community Plan]
* **Subscriber / Medicaid ID**: [ID Number]
* **Current Authorization #**: [AUTH-XXXXXX]
* **Current Auth Dates**: YYYY-MM-DD through YYYY-MM-DD
* **Requested Dates**: YYYY-MM-DD through YYYY-MM-DD
* **Requested Level of Care**: [ ] PHP (ASAM 2.5)  [ ] IOP (ASAM 2.1)
* **Requested Units / Days**: [e.g., 5 days PHP / 12 units IOP]

---

## ⚡ The 6 ASAM Dimensions Quick-Pitch (What Reviewers Listen For)

| ASAM Dimension | Clinical Status to Report |
| :--- | :--- |
| **Dim 1: Withdrawal / Intoxication** | Stable on MAT (Methadone [XX] mg daily). No acute medical withdrawal symptoms. No detox needed. |
| **Dim 2: Biomedical** | Medical conditions managed. Adherent to medications. Physical health stable for outpatient milieu. |
| **Dim 3: Emotional / Behavioral / Cognitive** | Co-occurring [MDD/PTSD/Anxiety]. PHQ-9: [XX], GAD-7: [XX]. Mild/Moderate symptoms; capable of group participation without disruptive behavior. Safety contract in place; denies SI/HI. |
| **Dim 4: Readiness to Change** | Stage: [Contemplation / Preparation]. Attending groups, but struggles with internal motivation outside program walls. Requires daily clinical accountability. |
| **Dim 5: Relapse Potential** | **CRITICAL FOR APPROVAL**: Experiencing active cravings (reported [X]/10). Identifies high risk of relapse without structured daytime milieu. Needs continued relapse prevention skill acquisition. |
| **Dim 6: Recovery Environment** | High-risk environment (peers using / unsupportive family / unstable housing). Cannot maintain sobriety in unsupervised evening hours without PHP/IOP grounding. |

---

## 📊 Concrete Metrics (Hard Data Reviewers Demand)
* **Program Attendance Rate**: [XX]% (e.g., 9 out of 10 days attended).
* **Reason for Any Missed Days**: [e.g., Medi-Drive transit delay / dental appointment; fully excused].
* **Toxicology / Drug Screen Results**:
  * Date: YYYY-MM-DD | Result: Negative for illicit substances / Positive for prescribed Methadone only.
  * Date: YYYY-MM-DD | Result: [Result]
* **Group Participation Rating**: [ ] Active & Engaged  [ ] Receptive but quiet  [ ] Needs prompting
* **Medication Adherence**: [ ] 100% compliant with psychiatric & MAT regimen.

---

## 🎯 Active Treatment Goals Being Worked On
1. **Goal 1 (Relapse Prevention)**: Developing written coping trigger inventory; practicing urge-surfing.
2. **Goal 2 (Emotion Regulation)**: Utilizing CBT thought logs to challenge catastrophic thinking.
3. **Goal 3 (Social / Case Management)**: Coordinating sober living placement and outpatient recovery network.

---

## 🚪 Discharge & Step-Down Criteria (The Exit Strategy)
*Reviewers will deny if they do not see a clear plan to step the client down.*

* **Anticipated Step-Down Level**: [e.g., PHP stepping down to IOP (3 days/wk) on [Date]]
* **Specific Clinical Milestones Required for Step-Down**:
  - [ ] 14 consecutive days of self-reported craving management without substance use.
  - [ ] Established sober support system (attending 2+ recovery meetings weekly).
  - [ ] Stable housing and transition plan finalized.

---

## 📝 Call Log & Determination
* **Date & Time of Call**: YYYY-MM-DD, HH:MM
* **Reviewer Name & Contact #**: [Name, Ext, Reference #]
* **Determination**:
  - [ ] **Approved**: [Number of Days/Units] through YYYY-MM-DD. Next review date: YYYY-MM-DD.
  - [ ] **Partial Approval**: [Details]
  - [ ] **Denial**: Reason stated: [Reason]. Peer-to-Peer requested for [Date/Time].
