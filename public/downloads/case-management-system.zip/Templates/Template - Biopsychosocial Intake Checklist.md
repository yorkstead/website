# Biopsychosocial & Intake Workflow Checklist

**Client ID**: {{client_id}}  
**Intake Date**: YYYY-MM-DD  
**Assessing Clinician / Case Manager**: [Name]  
**Referred Level of Care**: [ ] PHP (Partial Hospitalization)  [ ] IOP (Intensive Outpatient)

---

## 📑 Phase 1: Pre-Intake & Consent Verification (30-Min Fast-Track)

- [ ] **State & Facility Consent Forms Signed**:
  - [ ] Informed Consent for Treatment & Telehealth (if applicable)
  - [ ] Client Bill of Rights & Financial Agreement
  - [ ] HIPAA Notice of Privacy Practices
- [ ] **Releases of Information (42 CFR Part 2 Compliant)**:
  - [ ] Primary Care Physician (PCP)
  - [ ] Opioid Treatment Program (OTP) / Methadone Clinic (Mandatory if on MAT)
  - [ ] Emergency Contact / Family Support
  - [ ] Transportation Broker (Medi-Drive / NEMT consent)
  - [ ] Legal / Probation / Parole / Drug Court (if applicable)
- [ ] **Insurance / Benefit Verification**:
  - [ ] Active Medicaid / Commercial Policy Verified
  - [ ] Copay / Deductible / Auth Requirements Confirmed

---

## 🩺 Phase 2: ASAM 6-Dimension Rapid Assessment

### Dimension 1: Acute Intoxication / Withdrawal Potential
* Current Substance(s) of Use: [e.g., Fentanyl, Methamphetamine, Alcohol, Benzodiazepines]
* Last Use Date & Time: [YYYY-MM-DD, HH:MM]
* Withdrawal Risk: [ ] Low  [ ] Moderate  [ ] Severe / Unstable (Refer to Detox / Inpatient)
* Current CIWA / COWS Score (if indicated): [Score]

### Dimension 2: Biomedical Conditions & Complications
* Chronic Health Conditions: [e.g., Hepatitis C, Diabetes, Hypertension, Pregnancy, HIV]
* Physical Mobility / Ambulation: [ ] Independent  [ ] Assistive device  [ ] NEMT wheelchair needed
* Current Medications & Prescribers: [List]

### Dimension 3: Emotional, Behavioral, or Cognitive Conditions
* Psychiatric Diagnoses: [e.g., MDD, GAD, PTSD, Bipolar I/II, Schizoaffective]
* Suicide / Self-Harm Risk Assessment:
  - Ideation: [ ] None  [ ] Passive  [ ] Active (Requires Immediate Safety Protocol)
  - Columbia-Suicide Severity (C-SSRS) Level: [Low / Moderate / High]
* Trauma History: [Yes / No - brief note]
* Cognitive Ability to Participate in Group Programming (min 3 hrs/day for IOP, 5-6 hrs/day for PHP): [ ] Capable  [ ] Impaired

### Dimension 4: Readiness to Change
* Stage of Change: [Pre-contemplation / Contemplation / Preparation / Action]
* Motivation for IOP/PHP: [Internal recovery / External legal / Family pressure / Medical need]

### Dimension 5: Relapse, Continued Use, or Continued Problem Potential
* Cravings / Urges Severity (1-10): [Score]
* Relapse History & High-Risk Triggers: [People, places, emotions, unmanaged stress]
* Ability to Abstain Without Structured Daily Milieu: [Unlikely without IOP/PHP daily support]

### Dimension 6: Recovery Environment
* Housing Stability: [ ] Stable Own Residence  [ ] Sober Living  [ ] Shelter  [ ] Unhoused
* Social Supports: [Substance-using peer group vs. recovery-supportive network]
* Immediate Environmental Threats: [Domestic violence, active dealing in neighborhood, lack of food]

---

## 🛠️ Phase 3: Immediate Case Management Needs (Day 1 Actions)

- [ ] **Transportation (Medi-Drive / NEMT)**:
  - [ ] Standing ride request submitted to broker
  - [ ] Client given transport dispatch phone number & pickup instruction sheet
- [ ] **MAT / Methadone Coordination**:
  - [ ] Faxed initial intake confirmation to OTP clinic
  - [ ] Dosing schedule matched to PHP/IOP program hours (dosing prior to 8:30 AM)
- [ ] **Pharmacy & Medication Bridging**:
  - [ ] Psychiatric medications ordered / refill sync with pharmacy
- [ ] **Dietary / Food Security**:
  - [ ] PHP meal accommodations / food bank referral if unhoused
- [ ] **Initial Treatment Plan Scheduled**:
  - [ ] Target completion date: within 72 hours of admission

---

## ✍️ Intake Summary & Clinical Rationale
*Brief paragraph justifying why IOP or PHP is the least restrictive, clinically indicated level of care based on ASAM criteria:*

> "Client presents with severe [Diagnosis/Substances] and co-occurring [Mental Health Condition]. Inpatient medical detox is not required due to stable MAT dosing; however, Outpatient (OP) is inadequate due to significant relapse vulnerability (Dim 5) and lack of sober environmental supports (Dim 6). PHP/IOP structure provides required daily accountability, clinical skills training, and peer support."
