# Continuity of Care & Discharge Plan

**Client ID**: {{client_id}}  
**Client Initials**: {{initials}}  
**Discharge / Step-Down Date**: YYYY-MM-DD  
**Original Admission Date**: YYYY-MM-DD  
**Discharge Level of Care**: [ ] PHP stepping down to IOP  [ ] IOP stepping down to OP  [ ] Discharged / Complete  [ ] Administrative / AMA

---

## 🌟 Step-Down / Transition Overview

| Current Level of Care | Next Recommended Level of Care | Program / Provider Name | First Appointment Date & Time |
| :--- | :--- | :--- | :--- |
| **PHP** | **IOP (3 days/wk, 9 hrs)** | Internal / External Agency | YYYY-MM-DD @ 09:00 AM |
| **IOP** | **Outpatient Therapy (1 hr/wk)** | Community Mental Health Clinic | YYYY-MM-DD @ 02:00 PM |
| **MAT Maintenance** | **OTP Continuing Care** | [Name of Methadone Clinic] | Daily Dosing Continuing |

---

## 🤝 The Warm Handoff & Community Referral Checklist

### 1. Medication-Assisted Treatment (MAT) / Methadone Continuity
- [ ] OTP clinic notified of level of care change (PHP $\to$ IOP or IOP $\to$ OP).
- [ ] Dosing schedule verified so client can attend new program or work hours.
- [ ] Release of Information (ROI) re-authorized or extended for receiving provider.
- [ ] Last 30 days of toxicology and attendance records transmitted to OTP counselor.

### 2. Psychiatric & Medical Bridging
- [ ] Primary Care Physician (PCP) established: [Provider Name, Phone, Next Visit Date].
- [ ] Outpatient psychiatric provider assigned: [Provider Name, First Intake Date].
- [ ] 30-day medication bridge prescription sent to pharmacy: [Pharmacy Name & Address].
- [ ] No gap in psychotropic medications (antidepressants, mood stabilizers, sleep aids).

### 3. Transportation (Medi-Drive / NEMT) Transition
- [ ] Current standing ride reservations modified to reflect new schedule:
  - New days/hours updated with broker: [e.g., changed from 5 days/wk to Mon/Wed/Fri].
- [ ] Client provided updated confirmation numbers and pickup guidelines.

### 4. Recovery Environment & Social Determinants
- [ ] Housing secured: [Sober Living Home / Permanent Supportive Housing / Family].
  - House Manager / Landlord Contact: [Name & Phone]
- [ ] Community Support Connection:
  - 12-Step / SMART Recovery / All Recovery meeting schedule provided.
  - Recovery Coach / Peer Support Specialist assigned: [Name & Phone].

---

## 🛡️ Crisis & Relapse Prevention Safety Plan
*Copy provided to client upon step-down/discharge.*

1. **Warning Signs / Triggers that Crisis is Developing**:
   * Internal: [e.g., isolating, stopping medication, skipping morning dosing].
   * External: [e.g., running into old acquaintances, severe conflict at home].
2. **Internal Coping Strategies (What I can do on my own)**:
   * [e.g., 20-minute walk, listening to music, deep breathing, prayer/meditation].
3. **People & Social Settings That Provide Distraction / Support**:
   * [Name, Relationship, Phone Number]
   * [Name, Relationship, Phone Number]
4. **Professional & Crisis Contacts (24/7 Access)**:
   * **988 Suicide & Crisis Lifeline**: Call or text `988`
   * **SAMHSA National Helpline**: `1-800-662-4357`
   * **Local Mobile Crisis Team**: [Phone Number]
   * **Nearest Emergency Psychiatric Facility**: [Hospital Name, Address, Phone]

---

## ✍️ Continuity Handoff Signatures
* **Client Signature**: ___________________________ Date: YYYY-MM-DD
* **Case Manager / Transition Coordinator**: ___________________________ Date: YYYY-MM-DD
* **Receiving Provider Notification Confirmed By**: [ ] Phone  [ ] Secure Fax  [ ] EHR Direct Messaging
