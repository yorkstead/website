@echo off
title 100% Local & Offline Behavioral Health Intake Digitizer
echo ============================================================
echo   100% Local Offline Intake Digitizer (Zero Cloud / HIPAA)
echo ============================================================
echo.
echo Scanning Incoming-PDFs/ for new intake forms...
echo.

python "%~dp0scripts\digitize_intake_local.py"

echo.
echo ============================================================
echo Process finished. Press any key to close this window.
pause > nul
