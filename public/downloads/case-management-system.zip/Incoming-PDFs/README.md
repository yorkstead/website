# Incoming Intake PDFs

Drop scanned paper intake packets, handwritten biopsychosocial forms, or OTP faxes (PDF format) into this folder.

* When digitized, files can be moved into `Incoming-PDFs/Processed/`.
* See [[Guides/How-to-Digitize-Handwritten-PDFs|How to Digitize Handwritten PDFs]] for instructions.
