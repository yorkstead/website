# Medi-Drive & Transportation (NEMT) Roster

> [!IMPORTANT]
> **Weekly Reservation Rule**: All standing ride requests and schedule changes for the following week must be submitted to the NEMT broker before **Thursday at 2:00 PM**.

---

## 📞 Broker Dispatch & Escalation Rolodex

| Broker / Provider | Phone Number | Escalation / Supervisor Line | Online Portal URL | Typical Notice Required |
| :--- | :--- | :--- | :--- | :--- |
| **Modivcare (LogistiCare)** | 1-800-XXX-XXXX | 1-800-XXX-XXXX | `https://my.modivcare.com` | 48-72 hours |
| **Veyo / MTM** | 1-800-XXX-XXXX | 1-800-XXX-XXXX | `https://portal.veyo.com` | 48 hours |
| **SafeRide Health** | 1-855-XXX-XXXX | 1-855-XXX-XXXX | `https://saferidehealth.com` | 24-48 hours |
| **County Health Transit** | 1-XXX-XXX-XXXX | 1-XXX-XXX-XXXX | Direct dispatch line | 24 hours |

---

## 🚗 Active Client Standing Rides Roster

| Client ID | Initials | Medicaid / Member ID | Days Required | Morning Pickup Address & Gate | Pickup Window | Return Window | Broker & Trip # | Special Notes |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| *C-101* | *JD* | *MED1234567* | *M, W, F* | *123 Main St, Apt 4 (Gate #1234)* | *07:45 - 08:00* | *12:15 - 12:30* | *Modivcare #TR-8812* | *Curb-to-curb* |
| *C-102* | *TS* | *MED7654321* | *M, T, W, Th, F*| *456 Elm St, Sober Living* | *08:00 - 08:15* | *14:30 - 14:45* | *Veyo #VY-9941* | *PHP schedule; call upon arrival* |
| | | | | | | | | |
| | | | | | | | | |
| | | | | | | | | |

---

## ⚠️ Ride Issue, Delay & No-Show Log
*Record transit failures immediately for audit records, attendance excuses, and broker grievance filings.*

| Date | Client ID | Direction | Scheduled Time | Actual Arrival / Status | Dispatcher Contacted & Badge # | Resolution / Action Taken |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| YYYY-MM-DD | C-101 | Morning Inbound | 07:45 AM | Driver No-Show (08:20 AM) | Dispatcher Sarah (#412) | Dispatched priority rescue Uber Health ride. Client arrived 08:45 AM. |
| | | | | | | |
| | | | | | | |

---

## 📋 Weekly Transportation Audit Checklist (Every Thursday)
- [ ] Audit upcoming week's PHP/IOP attendance schedule against ride authorizations.
- [ ] Cross-check clients stepping down from PHP (5 days) to IOP (3 days) to avoid unnecessary rides.
- [ ] Cross-check clients discharged or scheduled for intake next week.
- [ ] Log on to broker portal(s) and confirm all recurring reservations show "Confirmed".
- [ ] Send printed or SMS ride confirmations to clients.
