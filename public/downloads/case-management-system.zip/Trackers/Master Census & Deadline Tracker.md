# Master Census & Deadline Tracker

> [!TIP]
> Keep this document updated daily. It is your master radar to prevent missed insurance authorizations (financial loss) and overdue treatment plan reviews (licensing & audit citations).

---

## 👥 Master Active Census

| Client ID | Initials | Level | Adm Date | Primary Payer | Current Auth Expires | Next Tx Plan Review Due | MAT Clinic | Medi-Drive Status | Primary Case Management Priority |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| *C-101* | *JD* | *IOP* | *2026-08-01* | *Medicaid BH* | *2026-09-15* | *2026-08-31 (DONE)* | *Pinnacle (Meth 90mg)* | *Standing M/W/F* | *Housing voucher application* |
| *C-102* | *TS* | *PHP* | *2026-08-25* | *United Health* | *2026-09-10* | *2026-09-24* | *None* | *Standing M-F* | *Psychiatry follow-up & step-down plan* |
| *C-104* | *RM* | *PHP* | *2026-08-18* | *Aetna BH* | *2026-09-08* | *2026-09-17* | *Acadia (Sub 16mg)* | *Self-Transport* | *UR Concurrent submission due today* |
| *C-107* | *LB* | *IOP* | *2026-07-20* | *State Medicaid*| *2026-09-20* | *2026-09-19* | *BAART (Meth 110mg)* | *Standing M/W/F* | *Resolve OTP counseling hold; step-down prep* |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |

---

## ⏳ Weekly Deadline Projection

### Week 1 (Current Week)
* **UR Concurrent Reviews Due**:
  - [ ] Client C-104: Aetna Auth expires 2026-09-08 $\rightarrow$ *Submit review note by 1:00 PM today*
  - [ ] Client C-102: UHC Auth expires 2026-09-10 $\rightarrow$ *Submit review note by Wednesday*
* **Treatment Plan Reviews Due**:
  - [ ] None this week.
* **Logistics / Handoffs**:
  - [ ] Thursday 2:00 PM: Submit Medi-Drive standing rides for next week.

### Week 2 (Next Week)
* **UR Concurrent Reviews Due**:
  - [ ] Client C-101: Medicaid Auth expires 2026-09-15 $\rightarrow$ *Submit review note by Friday prior*
* **Treatment Plan Reviews Due**:
  - [ ] Client C-104: 30-Day Treatment Plan Review due 2026-09-17.
  - [ ] Client C-107: 60-Day Treatment Plan Review due 2026-09-19.

---

## 📥 Pending Intakes Pipeline

| Referral Name / ID | Referral Source | Intake Scheduled Date & Time | Payer / Auth Status | Transport Needed? | Assigned Level |
| :--- | :--- | :--- | :--- | :--- | :--- |
| *Ref-201 (MK)* | *County Crisis Center* | *2026-09-08 @ 10:00 AM* | *Medicaid Verified - In Network* | *Yes - Pick-up scheduled* | *PHP Candidate* |
| *Ref-202 (AL)* | *Local OTP Clinic* | *2026-09-09 @ 11:30 AM* | *Commercial PPO - Auth pending* | *No - Self-drive* | *IOP Candidate* |
| | | | | | |
