# Medication-Assisted Treatment (MAT) & Methadone Coordination Log

> [!NOTE]
> **42 CFR Part 2 Compliance**: Ensure a signed, unexpired Specific Consent / Release of Information (ROI) is on file before transmitting clinical updates, toxicology, or attendance to Opioid Treatment Programs (OTPs).

---

## 🏥 Opioid Treatment Program (OTP) / Methadone Clinic Directory

| Clinic Name | Physical Address | Direct Dosing Nurse Phone | Assigned Counselor & Direct Phone | Secure Fax Number | Hours of Dosing |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Pinnacle Treatment Services** | 100 Health Way, Suite A | (555) 123-4567 ext 11 | Marcus Vance, CADC: (555) 123-4580 | (555) 123-4599 | Mon-Sat 05:30 - 11:00 AM |
| **Acadia Comprehensive Treatment** | 240 Recovery Blvd | (555) 987-6543 ext 2 | Brenda Ortiz, LCSW: (555) 987-6511 | (555) 987-6590 | Mon-Fri 05:00 - 10:30 AM |
| **BAART Programs** | 500 Central Ave | (555) 444-2222 ext 14 | David Kim, MSW: (555) 444-2233 | (555) 444-2299 | Mon-Sat 06:00 - 11:30 AM |

---

## 👥 Active Client MAT Roster

| Client ID | Initials | OTP Clinic | Medication & Dose | Daily Dosing Window | Phase / Take-Homes | ROI Expiry Date | Last UDS Shared | Status / Flags |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| *C-101* | *JD* | *Pinnacle* | *Methadone 90mg* | *06:30 - 07:15 AM* | *Daily In-Person* | *2027-01-15* | *2026-09-02* | *Stable; attending IOP M/W/F* |
| *C-104* | *RM* | *Acadia* | *Suboxone 16mg* | *Weekly pickup* | *Phase 2 (6 take-homes)*| *2026-11-30* | *2026-08-28* | *PHP 5 days/wk; verified* |
| *C-107* | *LB* | *BAART* | *Methadone 110mg*| *06:00 - 06:45 AM* | *Sunday take-home* | *2026-10-10* | *2026-09-01* | *Dosing hold warning: counseling overdue at OTP* |
| | | | | | | | | |

---

## 🔄 Weekly Toxicology & Attendance Exchange Log
*Batch transmission occurs every Wednesday afternoon.*

| Date Sent | Client ID | Receiving Clinic | Records Sent | Sent Via | Confirmed Received By | Follow-up Notes |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| YYYY-MM-DD | C-101 | Pinnacle | Last 2 weeks attendance & 2x negative UDS | Secure Fax | Nurse Elena | OTP cleared weekend take-home request. |
| YYYY-MM-DD | C-107 | BAART | Attendance letter verifying 15 group hrs completed | Direct Email | Counselor David Kim | Dosing hold lifted; client can dose as normal tomorrow. |
| | | | | | | |
| | | | | | | |

---

## 🚨 OTP Emergency & Dosing Hold Protocol
1. **Dosing Hold Triggered at Clinic**:
   - Call direct dosing nurse line immediately.
   - Ask for the exact hold reason: Medical (missed 3+ days, lab required) vs. Administrative (counseling session needed, fee unpaid, annual physical).
   - If administrative due to missing outpatient counseling, fax an official **"Proof of IOP/PHP Intensive Attendance"** letter within 60 minutes so client can dose before clinic doors close.
2. **Guest Dosing Coordination** (for medical appointments or approved travel):
   - Request guest dosing package at least 5 business days prior.
   - Send guest dosing request signed by Medical Director with client identification, current stable dose, and requested dates.
