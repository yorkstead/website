# How to Digitize Handwritten Intake PDFs into Obsidian

> [!NOTE]
> Case managers and intake coordinators often deal with paper intake packets, handwritten biopsychosocial forms, physician faxes, and paper consent signatures. Manually retyping handwriting takes 30–45 minutes per client. Modern AI vision eliminates this step.

---

## 🔍 How Handwriting OCR & Auto-Extraction Works

Traditional OCR (like old scanner software or Tesseract) only works on clean typed text and completely fails on cursive or messy clinician handwriting.

**Modern Multimodal AI (Gemini Vision)** reads handwriting like a human clinician does. It doesn't just read the words; it **understands clinical forms** and maps handwritten answers into structured fields:

```
┌────────────────────────┐      ┌─────────────────────────┐      ┌────────────────────────┐
│  Scanned Paper Packet  │ ───> │  AI Vision Extraction   │ ───> │  New Obsidian Note     │
│  (Handwritten PDF)     │      │  (Gemini Flash Vision)  │      │  [[Clients/C-XXXX.md]] │
└────────────────────────┘      └─────────────────────────┘      └────────────────────────┘
                                                                             │
                                                                             ▼
                                                                 Auto-updates Census &
                                                                 Transportation Trackers
```

---

## 🛠️ The 3 Ways to Implement This

### Method 1A: 100% Local Offline Script (Zero Cloud / Full HIPAA Compliance)
* **How it works**: Uses **Ollama** running locally on your computer with a Vision AI model (`llama3.2-vision` or `qwen2.5-vl`) and `PyMuPDF`.
* **Privacy**: **100% of processing happens on your local machine.** Zero internet connection required, zero API keys, and zero patient data leaves your hard drive.
* **How to run**:
  1. Drop your scanned PDF into `Incoming-PDFs/`.
  2. Double-click **`Run-Intake-Digitizer-LOCAL.bat`**.
  3. The local model converts pages to high-res images, transcribes handwriting, populates `Clients/C-XXXX.md`, and updates your trackers.

### Method 1B: Cloud-Assisted Script (Gemini 2.5 Flash Vision)
* **How it works**: Uses the official Google GenAI SDK.
* **Speed**: Extremely fast (1–3 seconds per document).
* **How to run**: Add your API key to `.env` and double-click **`Run-Intake-Digitizer.bat`**.

### Method 2: Assistant / Antigravity Direct Processing
* Whenever an intake arrives, you can drag the PDF into this assistant and say:
  > *"Digitize this intake PDF and create a new client file."*
* Antigravity reads the handwritten PDF directly, extracts all fields, creates the client note in `Clients/`, and updates the trackers for you.

### Method 3: Obsidian In-Vault AI Plugin (Copilot / Text Generator)
* Using community plugins like **Copilot for Obsidian** or **Text Generator** connected to a Gemini API key:
* Open a blank note $\to$ attach the scanned intake PDF $\to$ click "Extract Intake Form" $\to$ the fields automatically populate into the template.

---

## 🔒 HIPAA & Privacy Guidelines for AI OCR
* **Option A (De-Identification)**: Redact or omit Social Security numbers or full financial details prior to scanning. Use Client IDs/Record Numbers for note titles.
* **Option B (HIPAA BAA Compliant API)**: If using Google Cloud Vertex AI (Gemini via Google Cloud Enterprise) or an enterprise EHR integration, standard Business Associate Agreements (BAAs) cover PHI processing securely without data retention for training.
