# ASAM Dimensions & Medical Necessity Cheat Sheet

> [!TIP]
> Use these clinically defensible phrases and dimensional benchmarks when writing Biopsychosocial Assessments, Treatment Plans, 30/60/90-Day Reviews, and Utilization Review (UR) authorization requests.

---

## 🏛️ ASAM Level of Care Differentiators

| Feature | Level 2.5: Partial Hospitalization Program (PHP) | Level 2.1: Intensive Outpatient Program (IOP) | Level 1.0: Outpatient Therapy (OP) |
| :--- | :--- | :--- | :--- |
| **Hours per Week** | 20+ hours/week (typically 4–6 hrs/day, 5 days/wk) | 9–19 hours/week (typically 3 hrs/day, 3–5 days/wk) | 1–8 hours/week (typically 1–2 sessions/wk) |
| **Medical / Psychiatric** | Direct access to psychiatric & medical provider daily/weekly | Psychiatric evaluation and medication monitoring available | Independent provider management |
| **Dim 5 (Relapse Risk)** | Imminent risk of severe decompensation without daily structure | Moderate risk; requires multiple check-ins per week | Low risk; stable coping tools established |
| **Dim 6 (Environment)** | Highly unsupportive or chaotic home environment | Mixed environment; client has some recovery anchors | Supportive and stable living environment |

---

## 📚 The 6 ASAM Dimensions: Clinically Defensible Language

### Dimension 1: Acute Intoxication & Withdrawal Potential
* **PHP Justification**:
  * *"Client does not require 24-hour medical detox, as withdrawal symptoms are stabilized on current MAT regimen (Methadone [XX]mg daily); however, client requires daily clinical monitoring to manage cravings and verify physical stability."*
* **IOP Justification**:
  * *"Client is physically stable with no acute withdrawal signs. Medically cleared for ambulatory outpatient care. MAT dosing compliance is verified."*
* **Red Flags (Too high for IOP/PHP)**:
  * Active DTs, severe tremors, hallucinations, CIWA > 15, unmanaged seizures $\rightarrow$ *Requires ASAM Level 3.7 or 4.0 Inpatient Detox.*

---

### Dimension 2: Biomedical Conditions & Complications
* **PHP / IOP Language**:
  * *"Chronic biomedical conditions (e.g., Hepatitis C, Type II Diabetes, chronic pain) are stable and do not interfere with active group participation."*
  * *"Physical health conditions are secondary to primary substance use and emotional dysregulation; managed collaboratively with primary care."*

---

### Dimension 3: Emotional, Behavioral, or Cognitive Conditions
* **PHP Justification (High Need)**:
  * *"Client exhibits prominent symptoms of [MDD / PTSD / GAD] including moderate-to-severe dysphoria, hypervigilance, and emotional lability (PHQ-9: [XX], GAD-7: [XX]). Cognitive status is intact to benefit from multi-hour daily psychoeducational and DBT skills groups. Safety contract active; denies acute suicidal/homicidal ideation."*
* **IOP Justification**:
  * *"Psychiatric symptoms are stabilizing with psychotropic medication; client continues to require intensive group milieu to practice distress tolerance and prevent emotional decompensation leading to relapse."*
* **Audit Trap Warning**: If the client is acutely suicidal with intent or plan, they do NOT meet IOP/PHP criteria $\rightarrow$ *Escalate immediately to Inpatient Psychiatric / Crisis Stabilization.*

---

### Dimension 4: Readiness to Change
* **Defensible Phrases**:
  * *"Client demonstrates ambivalent motivation (Contemplation Stage of Change); acknowledges negative consequences of substance use but struggles with impulse control without daily program structure."*
  * *"Client demonstrates emerging insight into addiction cycle but requires continued motivational interviewing and structured peer accountability to transition into the Action Stage."*

---

### Dimension 5: Relapse, Continued Use, or Continued Problem Potential
* **THIS IS THE #1 DIMENSION REVIEWERS SCRUTINIZE FOR CONTINUED STAY.**
* **PHP Continued Stay Justification**:
  * *"Client continues to report intense, intrusive cravings (rated 7/10) during evening hours. Client has not yet internalized sufficient distress tolerance and relapse prevention tools to maintain abstinence in a less structured setting. Stepping down to OP at this time presents high probability of immediate relapse and hospitalization."*
* **IOP Continued Stay Justification**:
  * *"Client has achieved [14/30] days of continuous abstinence; however, client has recently encountered significant psychosocial stressors (e.g., housing transition, family conflict) which threaten recovery stability. Continued 9-hour weekly IOP structure is essential to reinforce relapse prevention mechanisms."*

---

### Dimension 6: Recovery Environment
* **PHP / IOP Language**:
  * *"Client resides in an environment with high relapse triggers (e.g., active substance users in immediate neighborhood, lack of sober social network). The therapeutic milieu of PHP/IOP serves as a vital protective buffer while stable sober living arrangements and community supports are established."*
  * *"Client's natural support network is severely fractured due to chronic addiction; case management is actively working on family reintegration and recovery community linkage."*

---

## 🎯 Cheat Sheet: Medical Necessity Buzzwords for Authorizations

| Do Use These Words (Reviewers Approve) | Avoid These Words (Reviewers Deny) |
| :--- | :--- |
| **"Intense daily structure required"** | "Client likes coming to group" |
| **"Active craving management & urge-surfing"** | "Client is doing great" (Triggers step-down denial!) |
| **"Developing distress tolerance & coping skills"** | "Client has been clean for 3 weeks" (Without context) |
| **"High relapse vulnerability without daily milieu"** | "Client just needs housing assistance" (Not clinical!) |
| **"Ambivalent insight requiring motivational groups"** | "Client doesn't want to change" |
| **"Unsafe recovery environment in evening hours"** | "Client has nowhere else to go" |
