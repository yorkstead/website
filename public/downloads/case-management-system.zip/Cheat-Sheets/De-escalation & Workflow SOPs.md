# De-escalation & Operational Crisis SOPs

> [!IMPORTANT]
> When multiple crises hit at once (e.g. an intake arrives late, a ride never showed up, and an OTP counselor is on line 1), follow these standardized protocols to de-escalate without losing your sanity.

---

## 🛑 1. Crisis Triage Matrix: Who Gets Handled First?

When 3 things happen simultaneously, prioritize by regulatory & medical severity:

```
PRIORITY 1: Medical / Psychiatric Safety (SI/HI, Severe withdrawal, Overdose risk)
    ⬇
PRIORITY 2: Regulatory / Dosing Hold Deadlines (OTP clinic closing in 30 mins)
    ⬇
PRIORITY 3: Active Transit Failures (Client stranded on street waiting for NEMT)
    ⬇
PRIORITY 4: UR Peer-to-Peer / Auth Deadlines (Expiring end-of-day)
    ⬇
PRIORITY 5: Routine Documentation & Next-Week Logistics (Tx plans, non-urgent rides)
```

---

## 🚗 2. Medi-Drive / NEMT Broker Escalation Scripts

When a driver fails to show up or drops the client off at the wrong location:

### Script for Dispatch:
> *"Hello, my name is [Name], Case Manager at [Facility Name]. I am calling regarding an urgent medical transportation failure for client [Client Medicaid / Member ID], reservation number [Trip #]. The scheduled pickup window was [Time], and the driver is currently [XX] minutes overdue. This client is attending a mandatory daily behavioral health program. Please locate the driver immediately or initiate an emergency will-call rescue ride."*

### If Dispatcher Pushes Back ("Wait 30 More Minutes"):
> *"This client has scheduled medical dosing and mandatory clinical hours. If the ride cannot arrive within 15 minutes, please transfer me to a dispatch supervisor and issue an authorized ride-share voucher (Uber Health / Lyft Concierge) under your emergency backup policy. I need your employee ID or badge number for the state insurance grievance report."*

---

## 💊 3. Methadone / OTP Dosing Crisis Protocol

### Scenario A: Client arrives in severe discomfort / Missed Morning Dosing
1. **Check Clinic Window**: Most OTP dosing windows close between 10:30 AM and 12:00 PM.
2. **Immediate Action**:
   - Call the dosing nurse line: *"This is [Name] at [Facility]. Client [Name/DOB] is currently with us. They missed their dosing window due to an unavoidable medical transit delay. Can the medical director authorize an emergency late dose if we transport them over right now?"*
3. **If OTP refuses late dose**:
   - Assess client for withdrawal symptoms using COWS (Clinical Opiate Withdrawal Scale).
   - Inform facility medical director / NP immediately for symptom comfort bridging if permitted under clinic policy.

### Scenario B: Dosing Hold for "Overdue Counseling"
* OTPs are federally mandated to require counseling sessions, but they will almost universally accept proof of PHP/IOP attendance in lieu of their own counseling:
* **Action**: Fax an official letter immediately stating:
  > *"Client [Name] is actively enrolled in our ASAM Level [2.1 / 2.5] program, completing [9 / 20] hours of clinical therapy weekly. Please accept our intensive clinical services as meeting OTP counseling compliance requirements and lift the administrative dosing hold."*

---

## 🏃 4. Against Medical Advice (AMA) / Elopement Risk SOP

When a client storms out of PHP/IOP or states "I'm checking out right now":

1. **Step 1: The 10-Minute De-escalation Pause**:
   - Do NOT immediately shove the AMA paperwork in their face (this increases hostility).
   - Offer a quiet room, a cup of water or coffee, and validate the emotional state:
     * *"I hear how overwhelmed and frustrated you feel right now. You have the right to leave if you choose, but let’s take 10 minutes to talk through what just happened before you make a decision that affects your housing or treatment."*
2. **Step 2: Assess Immediate Dangers**:
   - Is the client acutely intoxicated or expressing suicidal intent? If yes $\rightarrow$ Initiate safety/crisis hold protocol.
   - What is their living situation? Will leaving program cause an immediate eviction from sober living? Remind them gently of the consequences.
3. **Step 3: If Departure is Unavoidable**:
   - Provide Naloxone (Narcan) nasal spray kit.
   - Confirm safe ride/transit home (do not let client drive if impaired).
   - Review 988 lifeline and offer open-door policy: *"You are always welcome to call us back tomorrow morning to re-engage."*
   - Notify emergency contact (if ROI signed) and sober living house manager.

---

## 🛡️ 5. Avoiding Burnout: Boundary Rules for the Case Manager

1. **The 3:00 PM Shield**: Never schedule non-emergency client intake interviews after 2:30 PM. Late intakes guarantee you will be stuck at your desk until 7:00 PM writing the biopsychosocial assessment.
2. **Batch Phone Calls**: Turn off email/ringers during Block 4 (Clinical Writing). Return voicemails in 15-minute bursts at 12:45 PM and 4:15 PM.
3. **Standardize, Don't Improvise**: Keep this cheat sheet and the [[Cheat-Sheets/SMART Goals & Objectives Bank|SMART Goal Bank]] open side-by-side with your EHR.
