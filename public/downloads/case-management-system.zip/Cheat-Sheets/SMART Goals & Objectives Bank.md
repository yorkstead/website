# SMART Goals & Objectives Bank

> [!NOTE]
> Every objective in this bank follows the **SMART** standard:
> **S**pecific, **M**easurable, **A**chievable, **R**elevant, and **T**ime-bound.
> Copy and paste directly into your [[Templates/Template - Treatment Plan & Review|Treatment Plans and Reviews]].

---

## 1. Substance Use & Relapse Prevention

### Goal: Achieve and Maintain Continuous Abstinence
* **Long-Term Goal**: Client will achieve and maintain continuous abstinence from all non-prescribed mood-altering substances throughout enrollment in [PHP / IOP] as verified by random toxicology screens and self-reports.

#### Drop-In Measurable Objectives:
1. **Trigger Identification**:
   * *"Client will identify and document in writing at least 5 personal high-risk triggers (people, places, emotional states) and develop 2 corresponding coping actions for each within 14 days."*
2. **Urge-Surfing & Craving Management**:
   * *"Client will learn and demonstrate 2 urge-surfing/distress tolerance techniques during group therapy and report using these techniques to successfully navigate cravings at least 3 times per week over the next 30 days."*
3. **Relapse Prevention Plan**:
   * *"Client will formulate a comprehensive, written 5-step Relapse Prevention Plan including warning signs, emergency contacts, and safe environments, and present it to their primary counselor by [Target Date]."*
4. **Attendance & Group Engagement**:
   * *"Client will attend 100% of scheduled IOP/PHP clinical programming ([9 / 20] hours weekly) and contribute at least 1 personal insight or feedback per group session for the next 30 days."*

---

## 2. Co-Occurring Mental Health (Depression & Anxiety)

### Goal: Reduce Symptoms of Anxiety and Emotional Distress
* **Long-Term Goal**: Client will reduce overall symptoms of generalized anxiety and panic attacks from severe to mild-moderate as evidenced by a reduction on the GAD-7 screening tool over the next 60 days.

#### Drop-In Measurable Objectives:
1. **Grounding & Somatic Regulation**:
   * *"Client will practice and log one physiological grounding exercise (e.g., box breathing, progressive muscle relaxation, 5-4-3-2-1 sensory scan) daily for 30 consecutive days."*
2. **Cognitive Restructuring (CBT)**:
   * *"Client will complete at least 2 CBT thought records per week to identify cognitive distortions (e.g., catastrophizing, black-and-white thinking) and construct rational replacement thoughts with their therapist."*
3. **Behavioral Activation for Depression**:
   * *"Client will schedule and complete at least 3 positive, non-substance-related activities per week (e.g., physical exercise, walking outside, contacting a supportive friend) and rate mood before and after on a 1–10 scale."*

---

## 3. Medication-Assisted Treatment (MAT) & Medical Adherence

### Goal: Stabilize on MAT & Achieve Health Optimization
* **Long-Term Goal**: Client will demonstrate 100% adherence to their prescribed MAT regimen (Methadone / Suboxone) and all medical/psychiatric appointments to support sustained recovery.

#### Drop-In Measurable Objectives:
1. **Daily Dosing Consistency**:
   * *"Client will attend daily OTP dosing appointments within their designated morning window (06:30–07:30 AM) with zero missed unexcused doses over the next 30 days."*
2. **Care Coordination Participation**:
   * *"Client will sign and maintain active 42 CFR Part 2 Releases of Information for their OTP clinic, primary care provider, and psychiatrist within 24 hours of intake."*
3. **Psychiatric Evaluation & Follow-Up**:
   * *"Client will attend scheduled psychiatric medication evaluations every 2–4 weeks and verbalize understanding of prescribed psychotropic medications, target symptoms, and potential side effects."*

---

## 4. Case Management & Social Determinants of Health (SDOH)

### Goal: Resolve Environmental & Social Barriers to Recovery
* **Long-Term Goal**: Client will establish safe, stable living arrangements and dependable transportation to facilitate successful transition to Outpatient (OP) care.

#### Drop-In Measurable Objectives:
1. **Transportation Independence & Medi-Drive Compliance**:
   * *"Client will maintain 100% compliance with NEMT / Medi-Drive ride scheduling protocols, calling dispatch at least 48 hours prior to confirm rides or report schedule modifications."*
2. **Sober Living / Housing Search**:
   * *"Client will meet with Case Manager weekly to submit at least 2 housing or sober living applications per week, securing a confirmed move-in date prior to program discharge."*
3. **Community Recovery Support Linkage**:
   * *"Client will attend at least 2 community-based recovery support meetings (e.g., 12-Step, SMART Recovery, Refuge Recovery) per week and obtain contact information for at least 1 potential recovery peer/sponsor within 30 days."*
4. **Vocational / Entitlements Linkage**:
   * *"Client will work with Case Manager to complete applications for SNAP/food stamps, Medicaid renewal, or state vocational rehabilitation services within 21 days."*
