# 🌟 Welcome to Your Case Management System: Quick-Start Guide

> *"Take a deep breath. You are doing the work of four people. This system was built to take the chaos out of your head and put it on rails so you leave on time and never get caught off-guard by an audit or missed ride."*

---

## 🧭 The 30-Second Overview: What Is Where?

| What do you need to do? | Go to this note: |
| :--- | :--- |
| **Start your day & check deadlines** | [[00 - Dashboard\|00 - Dashboard]] |
| **See when your day should happen (batching)** | [[01 - Systems & Daily Cadence\|01 - Systems & Daily Cadence]] |
| **Check or change a ride for a client** | [[Trackers/Medi-Drive & Transportation Roster\|Medi-Drive Roster]] |
| **Check Methadone clinic contacts / holds** | [[Trackers/MAT & Methadone Coordination Log\|MAT Coordination Log]] |
| **Prepare for an insurance call (UR)** | [[Templates/Template - UR Concurrent Review Prep Sheet\|UR Prep Sheet]] |
| **Write a 30/60/90-Day Treatment Plan Review** | [[Templates/Template - Treatment Plan & Review\|Tx Plan Template]] + [[Cheat-Sheets/SMART Goals & Objectives Bank\|SMART Goal Bank]] |
| **Driver didn't show up or client threatening to leave** | [[Cheat-Sheets/De-escalation & Workflow SOPs\|Emergency SOPs]] |

---

## ⏰ Your Daily Game Plan (How to Run Your Day)

### Step 1: Morning Check-In (8:30 AM – 9:00 AM)
1. Open [[00 - Dashboard]].
2. Check the **Transport & MAT Flash**:
   - Did any client's ride fail? Check [[Trackers/Medi-Drive & Transportation Roster]].
   - Did an OTP/Methadone clinic call about a dosing hold? Check [[Trackers/MAT & Methadone Coordination Log]].
3. Look at the **Compliance Radar**: Are any insurance authorizations or treatment plan reviews due in the next 3 days?

### Step 2: Client & Intake Time (9:30 AM – 12:00 PM)
* Keep your focus on your clients.
* When doing a new intake, use the fast checklist: [[Templates/Template - Biopsychosocial Intake Checklist]].
* Make sure you get the **42 CFR Part 2 Release of Information (ROI)** signed for their OTP/Methadone clinic and transportation broker on Day 1.

### Step 3: Insurance & Authorizations (1:00 PM – 2:30 PM)
* Never do UR calls in the morning when insurance reviewer lines are clogged.
* Open [[Templates/Template - UR Concurrent Review Prep Sheet]]. 
* It gives you the exact ASAM clinical buzzwords reviewers need to hear (*"requires daily milieu"*, *"active craving management"*, *"unstable recovery environment"*).

### Step 4: Treatment Plan Writing (2:30 PM – 4:00 PM)
* Put your ringer on silent for 90 minutes.
* Open [[Templates/Template - Treatment Plan & Review]] side-by-side with [[Cheat-Sheets/SMART Goals & Objectives Bank]].
* **Do not write goals from scratch.** Copy and paste pre-written, audit-proof measurable goals for Substance Use, Depression, MAT, or Housing.

### Step 5: Pack Up for Tomorrow (4:00 PM – 5:00 PM)
* Confirm tomorrow's Medi-Drive rides.
* Log any notes into the [[Trackers/Master Census & Deadline Tracker]].
* Log off with peace of mind.

---

## 🚗 Medi-Drive: The Golden Rule
* **Every Thursday by 2:00 PM**: Audit all your active clients in [[Trackers/Medi-Drive & Transportation Roster]] and submit next week’s standing rides to the broker. This prevents 90% of Monday morning transport panics.

---

## 💊 Methadone / OTP: The Golden Rule
* **Every Wednesday afternoon**: Fax or email your weekly attendance and drug screen log to the OTP counselors using the directory in [[Trackers/MAT & Methadone Coordination Log]]. 
* When you send them attendance proactively, they rarely put administrative dosing holds on your clients.

---

## 🆘 In Case of Emergency
* Driver late or no-show? Open [[Cheat-Sheets/De-escalation & Workflow SOPs#2-medi-drive--nemt-broker-escalation-scripts|Medi-Drive Escalation Script]].
* Client threatening to walk out AMA? Open [[Cheat-Sheets/De-escalation & Workflow SOPs#4-against-medical-advice-ama--elopement-risk-sop|AMA De-escalation Protocol]].
* Insurance denied continued stay? Open [[Cheat-Sheets/ASAM Dimensions & Medical Necessity Cheat Sheet|ASAM Justifications]].
