@echo off
title Behavioral Health Intake Packet Digitizer
echo ============================================================
echo   Behavioral Health Intake Digitizer (Gemini Vision OCR)
echo ============================================================
echo.
echo Scanning Incoming-PDFs/ for new intake forms...
echo.

python "%~dp0scripts\digitize_intake.py"

echo.
echo ============================================================
echo Process finished. Press any key to close this window.
pause > nul
