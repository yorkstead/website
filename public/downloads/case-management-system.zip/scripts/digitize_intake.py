"""
Automated Handwriting OCR & Intake Packet Digitizer for Behavioral Health Case Management.
Reads scanned PDFs and image files from Incoming-PDFs/, transcribes handwritten clinical forms,
generates Clients/{client_id} ({initials}).md, and updates Census, Medi-Drive, and MAT trackers.
"""

import os
import sys
import json
import shutil
from pathlib import Path
from datetime import datetime, date, timedelta
from typing import Optional, List

# Ensure UTF-8 output on Windows consoles
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

from dotenv import load_dotenv
from pydantic import BaseModel, Field

# Load .env if present
VAULT_DIR = Path(__file__).resolve().parent.parent
load_dotenv(VAULT_DIR / ".env")

API_KEY = os.getenv("GEMINI_API_KEY")

if not API_KEY:
    print("=" * 60)
    print("⚠️  GEMINI_API_KEY NOT FOUND!")
    print("Please set your GEMINI_API_KEY environment variable or create")
    print(f"a .env file inside {VAULT_DIR} with:")
    print("GEMINI_API_KEY=your_actual_api_key_here")
    print("=" * 60)
    sys.exit(1)

from google import genai
from google.genai import types

# Initialize Gemini client
client = genai.Client(api_key=API_KEY)


class ExtractedIntake(BaseModel):
    client_id: Optional[str] = Field(None, description="Client ID or Medical Record Number, e.g. C-1045")
    initials: str = Field(..., description="Client Initials, e.g. JD")
    full_name: Optional[str] = Field(None, description="Full name if legible")
    dob: Optional[str] = Field(None, description="Date of birth YYYY-MM-DD or MM/DD/YYYY")
    age: Optional[str] = Field(None, description="Age in years")
    phone: Optional[str] = Field(None, description="Primary contact phone number")
    address: Optional[str] = Field(None, description="Physical address including apt and gate codes")
    emergency_contact: Optional[str] = Field(None, description="Emergency contact name, relation, and phone")
    living_situation: Optional[str] = Field(None, description="e.g. Sober Living, Family, Shelter, Unhoused")
    
    primary_dx: Optional[str] = Field("F10.20 (Alcohol Use Disorder, Severe)", description="Primary diagnosis code and name")
    secondary_dx: Optional[str] = Field(None, description="Secondary psychiatric or medical diagnosis")
    level_of_care: str = Field("PHP", description="Recommended Level of Care: PHP or IOP")
    admission_date: Optional[str] = Field(None, description="Intake/admission date YYYY-MM-DD")
    
    payer: Optional[str] = Field(None, description="Insurance or Medicaid plan name")
    insurance_id: Optional[str] = Field(None, description="Member ID / Medicaid ID")
    auth_number: Optional[str] = Field(None, description="Prior auth confirmation number if present")
    auth_expiration_date: Optional[str] = Field(None, description="Authorization end date YYYY-MM-DD")
    
    mat_status: Optional[str] = Field("None", description="e.g. Active - Methadone, Active - Suboxone, or None")
    mat_clinic: Optional[str] = Field(None, description="Name of OTP or Methadone clinic")
    dosing_dose: Optional[str] = Field(None, description="Current daily dose e.g. Methadone 85mg daily")
    dosing_window: Optional[str] = Field(None, description="Dosing window hours e.g. 06:30 - 07:30 AM")
    otp_counselor: Optional[str] = Field(None, description="Assigned OTP counselor name and phone")
    
    medi_drive_status: Optional[str] = Field("None", description="Active Standing, On Demand, or Self-Transport")
    transport_broker: Optional[str] = Field(None, description="NEMT broker name e.g. Modivcare, Veyo, SafeRide")
    pickup_address: Optional[str] = Field(None, description="Pickup address for transportation")
    standing_days: Optional[str] = Field(None, description="Days rides needed e.g. Mon, Wed, Fri or M-F")
    pickup_window: Optional[str] = Field(None, description="Scheduled morning pickup window e.g. 07:45 - 08:00 AM")
    return_window: Optional[str] = Field(None, description="Scheduled afternoon return window e.g. 12:15 - 12:30 PM")
    special_transit_needs: Optional[str] = Field(None, description="Wheelchair, front seat, curb-to-curb, gate code")
    
    substances_used: Optional[str] = Field(None, description="Substances reported and last date of use")
    withdrawal_symptoms: Optional[str] = Field(None, description="Any reported tremors, nausea, cravings, or CIWA/COWS notes")
    medical_conditions: Optional[str] = Field(None, description="Chronic medical problems, e.g. Hep C, Diabetes, pain")
    current_medications: Optional[str] = Field(None, description="Current prescribed medications and prescribers")
    psychiatric_symptoms: Optional[str] = Field(None, description="Depression, anxiety, trauma, sleep disturbance, PHQ/GAD scores")
    safety_notes: Optional[str] = Field("Denies SI/HI. Contract for safety intact.", description="Suicidal ideation, self-harm, or safety contract notes")
    recovery_environment: Optional[str] = Field(None, description="Triggers at home, peer group, family support")
    immediate_needs: Optional[str] = Field(None, description="Immediate case management needs (housing, food, clothes, PCP)")


PROMPT_EXTRACTION = """
You are an expert clinical behavioral health document parser with specialized capability to read challenging cursive and clinician handwriting.
Carefully review all pages of this scanned intake packet / biopsychosocial assessment / clinical form.
Transcribe and extract the information into the requested JSON schema.

Pay special attention to:
1. Client Initials, DOB, and Contact information (phone, physical address, apartment/gate codes).
2. Primary and secondary diagnoses, substances used, and date of last use.
3. Level of Care (Partial Hospitalization PHP vs Intensive Outpatient IOP).
4. Insurance / Medicaid plan name and Member ID.
5. Medication-Assisted Treatment (MAT): Methadone or Suboxone clinic name, daily dose, dosing window hours, and counselor.
6. Transportation (Medi-Drive / NEMT): pickup address, standing ride days (M-F or M/W/F), broker name, and gate codes.
7. Any handwritten notes regarding ASAM dimensions, cravings, psychiatric history, medical conditions, and case management needs.

If any field is illegible or not mentioned in the document, provide null or a reasonable default based on context.
Ensure all extracted dates follow YYYY-MM-DD whenever possible.
"""


def get_next_client_id(clients_dir: Path) -> str:
    """Generate the next sequential Client ID if missing from form."""
    existing_ids = []
    for f in clients_dir.glob("*.md"):
        name = f.stem
        if name.startswith("C-"):
            parts = name.split()
            id_part = parts[0].replace("C-", "")
            if id_part.isdigit():
                existing_ids.append(int(id_part))
    if existing_ids:
        return f"C-{max(existing_ids) + 1:04d}"
    return "C-1050"


def generate_client_markdown(data: ExtractedIntake) -> str:
    today = date.today().isoformat()
    adm_date = data.admission_date or today
    try:
        dt_adm = date.fromisoformat(adm_date)
        tx_review_due = (dt_adm + timedelta(days=30)).isoformat()
    except Exception:
        tx_review_due = (date.today() + timedelta(days=30)).isoformat()
        
    auth_exp = data.auth_expiration_date or (date.today() + timedelta(days=14)).isoformat()

    md = f"""---
client_id: "{data.client_id}"
initials: "{data.initials}"
status: "Active"
level_of_care: "{data.level_of_care}"
admission_date: {adm_date}
primary_dx: "{data.primary_dx or 'F10.20 (Substance Use Disorder)'}"
secondary_dx: "{data.secondary_dx or 'None'}"
payer: "{data.payer or 'State Medicaid'}"
insurance_id: "{data.insurance_id or 'TBD'}"
auth_number: "{data.auth_number or 'Pending'}"
auth_expiration_date: {auth_exp}
tx_plan_due_date: {tx_review_due}
mat_status: "{data.mat_status}"
mat_clinic: "{data.mat_clinic or 'N/A'}"
medi_drive_status: "{data.medi_drive_status}"
---

# Client Profile: {data.client_id} ({data.initials})

## 📌 Core Snapshot
* **Date of Birth**: {data.dob or 'Not recorded'} (Age: {data.age or 'N/A'})
* **Phone**: {data.phone or 'Not recorded'}
* **Current Living Situation**: {data.living_situation or 'Sober Living / Private Residence'}
* **Address**: {data.address or 'On file'}
* **Emergency Contact**: {data.emergency_contact or 'On file'}
* **Assigned Level of Care**: **{data.level_of_care}** (Admission: {adm_date})

---

## 🚌 Transportation / Medi-Drive Info
* **Medi-Drive Status**: {data.medi_drive_status}
* **NEMT Broker**: {data.transport_broker or 'Modivcare / County Transit'}
* **Standing Ride Days**: {data.standing_days or ('Mon - Fri' if data.level_of_care == 'PHP' else 'Mon, Wed, Fri')}
* **Pickup Window**: {data.pickup_window or '07:45 AM - 08:00 AM'}
* **Return Window**: {data.return_window or ('14:30 PM - 14:45 PM' if data.level_of_care == 'PHP' else '12:15 PM - 12:30 PM')}
* **Pickup Address & Gate**: {data.pickup_address or data.address or 'Same as residential address'}
* **Special Transit Needs**: {data.special_transit_needs or 'None noted'}

---

## 💊 Medication-Assisted Treatment (MAT) & Medical
* **MAT Status**: {data.mat_status}
* **OTP Clinic**: {data.mat_clinic or 'None'}
* **Current Dose**: {data.dosing_dose or 'N/A'}
* **Dosing Window**: {data.dosing_window or 'Morning prior to group start'}
* **OTP Counselor / Contact**: {data.otp_counselor or 'Pending verification'}
* **42 CFR Part 2 ROI Status**: Signed at Intake

---

## 🩺 Clinical & ASAM Findings (From Intake Packet)
* **Substances Used & Pattern**: {data.substances_used or 'Documented in EHR intake assessment'}
* **Withdrawal Signs & Intoxication Risk**: {data.withdrawal_symptoms or 'Stabilized; monitored in ambulatory setting'}
* **Biomedical / Chronic Conditions**: {data.medical_conditions or 'Non-contributory / Stable'}
* **Current Medications**: {data.current_medications or 'Reconciled with pharmacy'}
* **Emotional / Psychiatric Symptoms**: {data.psychiatric_symptoms or 'Co-occurring mood disturbance; eligible for group therapy'}
* **Safety / Self-Harm Risk**: {data.safety_notes}
* **Recovery Environment (Dim 6)**: {data.recovery_environment or 'Requires structured clinical support to manage external triggers'}
* **Immediate Case Management Priorities**: {data.immediate_needs or 'Transportation setup, OTP ROI sync, primary care linkage'}

---

## 📋 Compliance & Regulatory Dates
* **Initial Assessment Completed**: {adm_date}
* **Initial Treatment Plan Due**: Within 72 hours of admission
* **30-Day Tx Plan Review Due**: {tx_review_due}
* **Insurance Auth Expiration**: {auth_exp}

---

## 📝 Case Management Quick Log
| Date | Category | Summary / Contact Person | Next Step / Follow-up |
| :--- | :--- | :--- | :--- |
| {adm_date} | Intake | Digitized paper intake packet via OCR. Created master file. | Confirm standing Medi-Drive rides and OTP clinic ROI. |

---

## 🔗 Related Notes
* [[Trackers/Master Census & Deadline Tracker|Master Census Tracker]]
* [[Trackers/Medi-Drive & Transportation Roster|Medi-Drive Roster]]
* [[Trackers/MAT & Methadone Coordination Log|MAT Coordination Log]]
* [[Templates/Template - Treatment Plan & Review|Treatment Plan Template]]
* [[Templates/Template - UR Concurrent Review Prep Sheet|UR Prep Sheet]]
"""
    return md


def append_to_census(tracker_path: Path, data: ExtractedIntake):
    if not tracker_path.exists():
        return
    today = date.today().isoformat()
    adm = data.admission_date or today
    auth_exp = data.auth_expiration_date or (date.today() + timedelta(days=14)).isoformat()
    tx_due = (date.today() + timedelta(days=30)).isoformat()
    mat_summary = f"{data.mat_clinic or 'None'} ({data.dosing_dose or ''})".strip()
    if mat_summary == "None ()" or not mat_summary:
        mat_summary = "None"
        
    row = f"| *{data.client_id}* | *{data.initials}* | *{data.level_of_care}* | *{adm}* | *{data.payer or 'Medicaid'}* | *{auth_exp}* | *{tx_due}* | *{mat_summary}* | *{data.medi_drive_status}* | *Intake paperwork & initial tx plan* |\n"
    
    content = tracker_path.read_text(encoding="utf-8")
    if "| | | | | | | | | |" in content:
        content = content.replace("| | | | | | | | | |\n", row, 1)
    else:
        content += row
    tracker_path.write_text(content, encoding="utf-8")


def append_to_transport(tracker_path: Path, data: ExtractedIntake):
    if not tracker_path.exists() or data.medi_drive_status in ["None", "Self-Transport"]:
        return
    days = data.standing_days or ("M-F" if data.level_of_care == "PHP" else "M, W, F")
    addr = data.pickup_address or data.address or "Address on file"
    pick = data.pickup_window or "07:45 - 08:00"
    ret = data.return_window or ("14:30 - 14:45" if data.level_of_care == "PHP" else "12:15 - 12:30")
    broker = f"{data.transport_broker or 'Modivcare'} #{data.insurance_id or 'Pending'}"
    
    row = f"| *{data.client_id}* | *{data.initials}* | *{data.insurance_id or 'Pending'}* | *{days}* | *{addr}* | *{pick}* | *{ret}* | *{broker}* | *Digitized from intake* |\n"
    content = tracker_path.read_text(encoding="utf-8")
    if "| | | | | | | | |" in content:
        content = content.replace("| | | | | | | | |\n", row, 1)
    else:
        content += row
    tracker_path.write_text(content, encoding="utf-8")


def process_file(file_path: Path):
    print(f"\n📄 Processing: {file_path.name}")
    print("   ↳ Uploading to Gemini Vision for clinical handwriting extraction...")
    
    mime_type = "application/pdf"
    if file_path.suffix.lower() in [".png"]:
        mime_type = "image/png"
    elif file_path.suffix.lower() in [".jpg", ".jpeg"]:
        mime_type = "image/jpeg"
        
    uploaded_file = client.files.upload(file=file_path)
    
    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=[
            uploaded_file,
            PROMPT_EXTRACTION
        ],
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=ExtractedIntake,
            temperature=0.1
        )
    )
    
    extracted_json = json.loads(response.text)
    data = ExtractedIntake(**extracted_json)
    
    # Auto-assign client_id if missing
    clients_dir = VAULT_DIR / "Clients"
    clients_dir.mkdir(exist_ok=True)
    if not data.client_id or not data.client_id.strip():
        data.client_id = get_next_client_id(clients_dir)
        
    print(f"   ✅ Extraction Successful: {data.client_id} ({data.initials}) - Level: {data.level_of_care}")
    if data.mat_status and data.mat_status != "None":
        print(f"      • MAT: {data.mat_status} at {data.mat_clinic} ({data.dosing_dose})")
    if data.medi_drive_status and data.medi_drive_status != "None":
        print(f"      • Transportation: {data.medi_drive_status} ({data.standing_days})")
        
    # 1. Write Client Note
    client_filename = f"{data.client_id} ({data.initials}).md"
    client_file_path = clients_dir / client_filename
    md_content = generate_client_markdown(data)
    client_file_path.write_text(md_content, encoding="utf-8")
    print(f"   📝 Generated client profile: Clients/{client_filename}")
    
    # 2. Update Master Census Tracker
    census_tracker = VAULT_DIR / "Trackers" / "Master Census & Deadline Tracker.md"
    append_to_census(census_tracker, data)
    print("   📊 Appended client to Master Census & Deadline Tracker")
    
    # 3. Update Medi-Drive Roster
    transport_tracker = VAULT_DIR / "Trackers" / "Medi-Drive & Transportation Roster.md"
    append_to_transport(transport_tracker, data)
    print("   🚌 Updated Medi-Drive & Transportation Roster")
    
    # 4. Move processed file to Processed folder
    processed_dir = file_path.parent / "Processed"
    processed_dir.mkdir(exist_ok=True)
    target_path = processed_dir / file_path.name
    shutil.move(str(file_path), str(target_path))
    print(f"   📁 Moved original PDF to: Incoming-PDFs/Processed/{file_path.name}")


def main():
    incoming_dir = VAULT_DIR / "Incoming-PDFs"
    if not incoming_dir.exists():
        incoming_dir.mkdir(exist_ok=True)
        
    supported_exts = {".pdf", ".png", ".jpg", ".jpeg"}
    files_to_process = [
        f for f in incoming_dir.iterdir()
        if f.is_file() and f.suffix.lower() in supported_exts and f.name != "README.md"
    ]
    
    if not files_to_process:
        print("=" * 60)
        print(f"📂 No files found in: {incoming_dir}")
        print("Drop a scanned intake PDF or image into Incoming-PDFs/ and run again!")
        print("=" * 60)
        return
        
    print(f"🚀 Found {len(files_to_process)} document(s) to digitize in {incoming_dir.name}:")
    for f in files_to_process:
        try:
            process_file(f)
        except Exception as e:
            print(f"   ❌ Error processing {f.name}: {e}")
            
    print("\n🎉 All documents processed! Open Obsidian to view your updated files.")


if __name__ == "__main__":
    main()
