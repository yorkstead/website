"""
100% Local & Offline Intake Digitizer for Behavioral Health Case Management.
Processes scanned PDFs locally using PyMuPDF and local Vision AI (via Ollama) or local OCR.
Zero data leaves your computer - 100% HIPAA and privacy compliant.
"""

import os
import sys
import json
import base64
import shutil
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime, date, timedelta
from typing import Optional, List, Dict, Any

# Ensure UTF-8 output on Windows consoles
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

import pymupdf
from pydantic import BaseModel, Field

VAULT_DIR = Path(__file__).resolve().parent.parent
INCOMING_DIR = VAULT_DIR / "Incoming-PDFs"
CLIENTS_DIR = VAULT_DIR / "Clients"
TRACKERS_DIR = VAULT_DIR / "Trackers"
PROCESSED_DIR = INCOMING_DIR / "Processed"

# Default local Ollama endpoint
OLLAMA_URL = os.getenv("OLLAMA_HOST", "http://localhost:11434")
DEFAULT_LOCAL_MODEL = os.getenv("LOCAL_VISION_MODEL", "llama3.2-vision")


class ExtractedIntake(BaseModel):
    client_id: Optional[str] = Field(None, description="Client ID or Medical Record Number")
    initials: str = Field(..., description="Client Initials, e.g. JD")
    full_name: Optional[str] = Field(None, description="Full name if legible")
    dob: Optional[str] = Field(None, description="Date of birth YYYY-MM-DD")
    age: Optional[str] = Field(None, description="Age")
    phone: Optional[str] = Field(None, description="Primary contact phone")
    address: Optional[str] = Field(None, description="Physical address")
    emergency_contact: Optional[str] = Field(None, description="Emergency contact name and phone")
    living_situation: Optional[str] = Field(None, description="Sober Living, Family, Shelter, Unhoused")
    
    primary_dx: Optional[str] = Field("F10.20 (Substance Use Disorder)", description="Primary diagnosis")
    secondary_dx: Optional[str] = Field(None, description="Secondary diagnosis")
    level_of_care: str = Field("PHP", description="Level of care: PHP or IOP")
    admission_date: Optional[str] = Field(None, description="Intake date YYYY-MM-DD")
    
    payer: Optional[str] = Field(None, description="Insurance or Medicaid plan")
    insurance_id: Optional[str] = Field(None, description="Member ID")
    auth_number: Optional[str] = Field(None, description="Prior auth number")
    auth_expiration_date: Optional[str] = Field(None, description="Auth end date YYYY-MM-DD")
    
    mat_status: Optional[str] = Field("None", description="Active - Methadone, Active - Suboxone, or None")
    mat_clinic: Optional[str] = Field(None, description="Name of OTP or clinic")
    dosing_dose: Optional[str] = Field(None, description="Daily dose e.g. Methadone 85mg")
    dosing_window: Optional[str] = Field(None, description="Dosing hours e.g. 06:30 - 07:30 AM")
    otp_counselor: Optional[str] = Field(None, description="Assigned OTP counselor")
    
    medi_drive_status: Optional[str] = Field("None", description="Active Standing, On Demand, or Self-Transport")
    transport_broker: Optional[str] = Field(None, description="NEMT broker name")
    pickup_address: Optional[str] = Field(None, description="Pickup address")
    standing_days: Optional[str] = Field(None, description="Days rides needed e.g. M-F or Mon, Wed, Fri")
    pickup_window: Optional[str] = Field(None, description="Pickup window e.g. 07:45 - 08:00 AM")
    return_window: Optional[str] = Field(None, description="Return window e.g. 12:15 - 12:30 PM")
    special_transit_needs: Optional[str] = Field(None, description="Wheelchair, gate codes, etc.")
    
    substances_used: Optional[str] = Field(None, description="Substances reported and last use date")
    withdrawal_symptoms: Optional[str] = Field(None, description="Withdrawal or CIWA/COWS notes")
    medical_conditions: Optional[str] = Field(None, description="Chronic medical problems")
    current_medications: Optional[str] = Field(None, description="Current medications")
    psychiatric_symptoms: Optional[str] = Field(None, description="Depression, anxiety, PTSD, trauma")
    safety_notes: Optional[str] = Field("Denies SI/HI. Contract for safety intact.", description="Safety notes")
    recovery_environment: Optional[str] = Field(None, description="Recovery environment and triggers")
    immediate_needs: Optional[str] = Field(None, description="Immediate case management priorities")


PROMPT_EXTRACTION = """
You are an expert clinical behavioral health document parser.
Read this scanned medical intake packet / biopsychosocial form, including all handwritten notes, checkmarks, and doctor handwriting.
Extract the fields into a valid JSON object matching this schema:
{
  "client_id": "string or null",
  "initials": "string",
  "full_name": "string or null",
  "dob": "YYYY-MM-DD or string",
  "age": "string or null",
  "phone": "string or null",
  "address": "string or null",
  "emergency_contact": "string or null",
  "living_situation": "string or null",
  "primary_dx": "string",
  "secondary_dx": "string or null",
  "level_of_care": "PHP or IOP",
  "admission_date": "YYYY-MM-DD",
  "payer": "string or null",
  "insurance_id": "string or null",
  "auth_number": "string or null",
  "auth_expiration_date": "YYYY-MM-DD",
  "mat_status": "Active - Methadone, Active - Suboxone, or None",
  "mat_clinic": "string or null",
  "dosing_dose": "string or null",
  "dosing_window": "string or null",
  "otp_counselor": "string or null",
  "medi_drive_status": "Active Standing, On Demand, or Self-Transport",
  "transport_broker": "string or null",
  "pickup_address": "string or null",
  "standing_days": "string or null",
  "pickup_window": "string or null",
  "return_window": "string or null",
  "special_transit_needs": "string or null",
  "substances_used": "string or null",
  "withdrawal_symptoms": "string or null",
  "medical_conditions": "string or null",
  "current_medications": "string or null",
  "psychiatric_symptoms": "string or null",
  "safety_notes": "string",
  "recovery_environment": "string or null",
  "immediate_needs": "string or null"
}

IMPORTANT: Respond ONLY with valid JSON. No conversational preamble or trailing explanation.
"""


def check_ollama_status() -> bool:
    """Check if local Ollama server is running."""
    try:
        req = urllib.request.Request(f"{OLLAMA_URL}/api/tags", method="GET")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return resp.status == 200
    except Exception:
        return False


def get_next_client_id() -> str:
    CLIENTS_DIR.mkdir(exist_ok=True)
    existing_ids = []
    for f in CLIENTS_DIR.glob("*.md"):
        name = f.stem
        if name.startswith("C-"):
            parts = name.split()
            id_part = parts[0].replace("C-", "")
            if id_part.isdigit():
                existing_ids.append(int(id_part))
    if existing_ids:
        return f"C-{max(existing_ids) + 1:04d}"
    return "C-1050"


def convert_pdf_to_images(pdf_path: Path, max_pages: int = 4) -> List[str]:
    """Convert PDF pages to base64 JPEG images locally using PyMuPDF."""
    images_base64 = []
    doc = pymupdf.open(pdf_path)
    for i in range(min(len(doc), max_pages)):
        page = doc[i]
        # Render page at 200 DPI for high-detail handwriting OCR
        pix = page.get_pixmap(dpi=200)
        img_bytes = pix.tobytes("jpeg")
        b64 = base64.b64encode(img_bytes).decode("utf-8")
        images_base64.append(b64)
    doc.close()
    return images_base64


def query_local_ollama(images_b64: List[str], model: str = DEFAULT_LOCAL_MODEL) -> Dict[str, Any]:
    """Send image to local Ollama Vision model."""
    url = f"{OLLAMA_URL}/api/generate"
    payload = {
        "model": model,
        "prompt": PROMPT_EXTRACTION,
        "images": images_b64,
        "stream": False,
        "format": "json"
    }
    
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    
    with urllib.request.urlopen(req, timeout=180) as resp:
        res_json = json.loads(resp.read().decode("utf-8"))
        raw_response = res_json.get("response", "{}")
        # Parse JSON
        return json.loads(raw_response)


def generate_client_markdown(data: ExtractedIntake) -> str:
    today = date.today().isoformat()
    adm_date = data.admission_date or today
    try:
        dt_adm = date.fromisoformat(adm_date)
        tx_review_due = (dt_adm + timedelta(days=30)).isoformat()
    except Exception:
        tx_review_due = (date.today() + timedelta(days=30)).isoformat()
        
    auth_exp = data.auth_expiration_date or (date.today() + timedelta(days=14)).isoformat()

    md = f"""---
client_id: "{data.client_id}"
initials: "{data.initials}"
status: "Active"
level_of_care: "{data.level_of_care}"
admission_date: {adm_date}
primary_dx: "{data.primary_dx or 'F10.20 (Substance Use Disorder)'}"
secondary_dx: "{data.secondary_dx or 'None'}"
payer: "{data.payer or 'State Medicaid'}"
insurance_id: "{data.insurance_id or 'TBD'}"
auth_number: "{data.auth_number or 'Pending'}"
auth_expiration_date: {auth_exp}
tx_plan_due_date: {tx_review_due}
mat_status: "{data.mat_status}"
mat_clinic: "{data.mat_clinic or 'N/A'}"
medi_drive_status: "{data.medi_drive_status}"
---

# Client Profile: {data.client_id} ({data.initials})

## 📌 Core Snapshot
* **Date of Birth**: {data.dob or 'Not recorded'} (Age: {data.age or 'N/A'})
* **Phone**: {data.phone or 'Not recorded'}
* **Current Living Situation**: {data.living_situation or 'Sober Living / Private Residence'}
* **Address**: {data.address or 'On file'}
* **Emergency Contact**: {data.emergency_contact or 'On file'}
* **Assigned Level of Care**: **{data.level_of_care}** (Admission: {adm_date})

---

## 🚌 Transportation / Medi-Drive Info
* **Medi-Drive Status**: {data.medi_drive_status}
* **NEMT Broker**: {data.transport_broker or 'Modivcare / County Transit'}
* **Standing Ride Days**: {data.standing_days or ('Mon - Fri' if data.level_of_care == 'PHP' else 'Mon, Wed, Fri')}
* **Pickup Window**: {data.pickup_window or '07:45 AM - 08:00 AM'}
* **Return Window**: {data.return_window or ('14:30 PM - 14:45 PM' if data.level_of_care == 'PHP' else '12:15 PM - 12:30 PM')}
* **Pickup Address & Gate**: {data.pickup_address or data.address or 'Same as residential address'}
* **Special Transit Needs**: {data.special_transit_needs or 'None noted'}

---

## 💊 Medication-Assisted Treatment (MAT) & Medical
* **MAT Status**: {data.mat_status}
* **OTP Clinic**: {data.mat_clinic or 'None'}
* **Current Dose**: {data.dosing_dose or 'N/A'}
* **Dosing Window**: {data.dosing_window or 'Morning prior to group start'}
* **OTP Counselor / Contact**: {data.otp_counselor or 'Pending verification'}
* **42 CFR Part 2 ROI Status**: Signed at Intake

---

## 🩺 Clinical & ASAM Findings (From Intake Packet)
* **Substances Used & Pattern**: {data.substances_used or 'Documented in EHR intake assessment'}
* **Withdrawal Signs & Intoxication Risk**: {data.withdrawal_symptoms or 'Stabilized; monitored in ambulatory setting'}
* **Biomedical / Chronic Conditions**: {data.medical_conditions or 'Non-contributory / Stable'}
* **Current Medications**: {data.current_medications or 'Reconciled with pharmacy'}
* **Emotional / Psychiatric Symptoms**: {data.psychiatric_symptoms or 'Co-occurring mood disturbance; eligible for group therapy'}
* **Safety / Self-Harm Risk**: {data.safety_notes}
* **Recovery Environment (Dim 6)**: {data.recovery_environment or 'Requires structured clinical support to manage external triggers'}
* **Immediate Case Management Priorities**: {data.immediate_needs or 'Transportation setup, OTP ROI sync, primary care linkage'}

---

## 📋 Compliance & Regulatory Dates
* **Initial Assessment Completed**: {adm_date}
* **Initial Treatment Plan Due**: Within 72 hours of admission
* **30-Day Tx Plan Review Due**: {tx_review_due}
* **Insurance Auth Expiration**: {auth_exp}

---

## 📝 Case Management Quick Log
| Date | Category | Summary / Contact Person | Next Step / Follow-up |
| :--- | :--- | :--- | :--- |
| {adm_date} | Intake | Digitized paper intake packet via local offline OCR. Created master file. | Confirm standing Medi-Drive rides and OTP clinic ROI. |

---

## 🔗 Related Notes
* [[Trackers/Master Census & Deadline Tracker|Master Census Tracker]]
* [[Trackers/Medi-Drive & Transportation Roster|Medi-Drive Roster]]
* [[Trackers/MAT & Methadone Coordination Log|MAT Coordination Log]]
* [[Templates/Template - Treatment Plan & Review|Treatment Plan Template]]
* [[Templates/Template - UR Concurrent Review Prep Sheet|UR Prep Sheet]]
"""
    return md


def append_to_census(tracker_path: Path, data: ExtractedIntake):
    if not tracker_path.exists():
        return
    today = date.today().isoformat()
    adm = data.admission_date or today
    auth_exp = data.auth_expiration_date or (date.today() + timedelta(days=14)).isoformat()
    tx_due = (date.today() + timedelta(days=30)).isoformat()
    mat_summary = f"{data.mat_clinic or 'None'} ({data.dosing_dose or ''})".strip()
    if mat_summary == "None ()" or not mat_summary:
        mat_summary = "None"
        
    row = f"| *{data.client_id}* | *{data.initials}* | *{data.level_of_care}* | *{adm}* | *{data.payer or 'Medicaid'}* | *{auth_exp}* | *{tx_due}* | *{mat_summary}* | *{data.medi_drive_status}* | *Intake paperwork & initial tx plan* |\n"
    content = tracker_path.read_text(encoding="utf-8")
    if "| | | | | | | | | |" in content:
        content = content.replace("| | | | | | | | | |\n", row, 1)
    else:
        content += row
    tracker_path.write_text(content, encoding="utf-8")


def append_to_transport(tracker_path: Path, data: ExtractedIntake):
    if not tracker_path.exists() or data.medi_drive_status in ["None", "Self-Transport"]:
        return
    days = data.standing_days or ("M-F" if data.level_of_care == "PHP" else "M, W, F")
    addr = data.pickup_address or data.address or "Address on file"
    pick = data.pickup_window or "07:45 - 08:00"
    ret = data.return_window or ("14:30 - 14:45" if data.level_of_care == "PHP" else "12:15 - 12:30")
    broker = f"{data.transport_broker or 'Modivcare'} #{data.insurance_id or 'Pending'}"
    
    row = f"| *{data.client_id}* | *{data.initials}* | *{data.insurance_id or 'Pending'}* | *{days}* | *{addr}* | *{pick}* | *{ret}* | *{broker}* | *Digitized from intake* |\n"
    content = tracker_path.read_text(encoding="utf-8")
    if "| | | | | | | | |" in content:
        content = content.replace("| | | | | | | | |\n", row, 1)
    else:
        content += row
    tracker_path.write_text(content, encoding="utf-8")


def process_file_locally(file_path: Path):
    print(f"\n📄 [Local Offline] Processing: {file_path.name}")
    
    # 1. Convert PDF pages to high-res images locally
    if file_path.suffix.lower() == ".pdf":
        print("   ↳ Converting PDF pages to local high-res images via PyMuPDF...")
        images_b64 = convert_pdf_to_images(file_path)
    else:
        # Direct image file
        with open(file_path, "rb") as img_f:
            b64 = base64.b64encode(img_f.read()).decode("utf-8")
            images_b64 = [b64]
            
    print(f"   ↳ Extracted {len(images_b64)} page image(s) locally.")
    print("   ↳ Analyzing handwriting via local Ollama Vision AI...")
    
    raw_dict = query_local_ollama(images_b64)
    data = ExtractedIntake(**raw_dict)
    
    if not data.client_id or not data.client_id.strip():
        data.client_id = get_next_client_id()
        
    print(f"   ✅ Local Extraction Complete: {data.client_id} ({data.initials}) - Level: {data.level_of_care}")
    if data.mat_status and data.mat_status != "None":
        print(f"      • MAT: {data.mat_status} at {data.mat_clinic} ({data.dosing_dose})")
    if data.medi_drive_status and data.medi_drive_status != "None":
        print(f"      • Transportation: {data.medi_drive_status} ({data.standing_days})")
        
    # 2. Write client note
    client_filename = f"{data.client_id} ({data.initials}).md"
    client_file_path = CLIENTS_DIR / client_filename
    md_content = generate_client_markdown(data)
    client_file_path.write_text(md_content, encoding="utf-8")
    print(f"   📝 Generated client profile: Clients/{client_filename}")
    
    # 3. Update trackers
    append_to_census(TRACKERS_DIR / "Master Census & Deadline Tracker.md", data)
    print("   📊 Appended client to Master Census & Deadline Tracker")
    append_to_transport(TRACKERS_DIR / "Medi-Drive & Transportation Roster.md", data)
    print("   🚌 Updated Medi-Drive & Transportation Roster")
    
    # 4. Move to processed
    PROCESSED_DIR.mkdir(exist_ok=True)
    target = PROCESSED_DIR / file_path.name
    shutil.move(str(file_path), str(target))
    print(f"   📁 Moved processed file to: Incoming-PDFs/Processed/{file_path.name}")


def main():
    print("=" * 65)
    print("🔒 100% Local Offline Intake Digitizer (Zero Cloud / Full HIPAA)")
    print("=" * 65)
    
    if not check_ollama_status():
        print(f"❌ Local Ollama service is not running at {OLLAMA_URL}!")
        print()
        print("To run 100% offline handwriting recognition on your machine:")
        print("1. Download & Install Ollama (free, open source) from: https://ollama.com")
        print("2. Open your terminal or powershell and run:")
        print("     ollama run llama3.2-vision")
        print("3. Run this script again!")
        print("=" * 65)
        sys.exit(1)
        
    INCOMING_DIR.mkdir(exist_ok=True)
    supported_exts = {".pdf", ".png", ".jpg", ".jpeg"}
    files = [
        f for f in INCOMING_DIR.iterdir()
        if f.is_file() and f.suffix.lower() in supported_exts and f.name != "README.md"
    ]
    
    if not files:
        print(f"📂 No files found in: {INCOMING_DIR}")
        print("Drop a scanned intake PDF or image into Incoming-PDFs/ and run again.")
        return
        
    print(f"🚀 Found {len(files)} document(s) in Incoming-PDFs/. Processing locally...")
    for f in files:
        try:
            process_file_locally(f)
        except Exception as e:
            print(f"   ❌ Error processing {f.name}: {e}")
            
    print("\n🎉 All documents digitized 100% locally! Open Obsidian to review.")


if __name__ == "__main__":
    main()
