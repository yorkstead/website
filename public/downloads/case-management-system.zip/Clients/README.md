# Client Master Files

Individual client profiles created from [[Templates/Template - Client Master File|Client Master File Template]] are stored here.

### File Naming Convention
* Use `Client-ID (Initials).md` (e.g., `C-1042 (JD).md`).
* Avoid using full names in file titles to preserve HIPAA compliance in folder structures.
