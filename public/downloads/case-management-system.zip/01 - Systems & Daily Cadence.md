# Systems, Daily Cadence & Operational Protocols

## The Multi-Hat Dilemma
Juggling Intake + Case Management + IOP/PHP Tracking + Medi-Drive + Methadone + UR Authorizations + Treatment Plans is mathematically impossible if approached reactively. Every incoming phone call or transport glitch threatens to derail clinical documentation.

The solution is **defensive scheduling, strict batching, and standardized workflows.**

---

## ⏰ The 5-Block Master Daily Schedule

```
08:30 ─── 09:30   BLOCK 1: Logistics Firewall & Morning Triage
09:30 ─── 12:00   BLOCK 2: High-Touch Client Contact & Intakes
12:00 ─── 13:00   LUNCH & DISENGAGEMENT (Non-negotiable recovery)
13:00 ─── 14:30   BLOCK 3: Utilization Review (UR) & Auth Submissions
14:30 ─── 16:00   BLOCK 4: Deep Clinical Writing (Tx Plans & Reviews)
16:00 ─── 17:00   BLOCK 5: Next-Day Wrap & Continuity Communications
```

### Block 1 (08:30 - 09:30): Logistics Firewall
* **Goal**: Clear all physical and transit barriers before clinical programming begins.
1. **Attendance vs. Transport reconciliation**: Match the day's IOP/PHP attendance sheet with the [[Trackers/Medi-Drive & Transportation Roster|Medi-Drive Roster]]. If a client hasn't arrived 15 minutes past group start, call transport broker dispatch immediately.
2. **Methadone / MAT Holds**: Check voicemails/faxes from local Opioid Treatment Programs (OTPs). Address dosing flags (e.g., sanction holds, missed consecutive doses, guest dosing confirmations).
3. **Daily Census check**: Update active client count for billing and lunch counts.

### Block 2 (09:30 - 12:00): High-Touch Client Contact & Intakes
* **Goal**: Face-to-face clinical engagement when energy is highest.
1. Biopsychosocial intake interviews and safety assessments.
2. One-on-one case management check-ins (housing, legal, primary care, benefits).
3. Immediate post-intake consent signatures (Release of Information - 42 CFR Part 2).

### Block 3 (13:00 - 14:30): Utilization Review (UR) Window
* **Goal**: Protect revenue and authorized lengths of stay without phone tag.
1. Insurance calls are best placed between 1:00 PM and 2:30 PM (after reviewer morning huddles).
2. Use the [[Templates/Template - UR Concurrent Review Prep Sheet|UR Concurrent Review Prep Sheet]] with the 6 ASAM dimensions pre-filled.
3. Submit clinical notes via online payor portals (Availity, Optum, Medicaid provider portals) rather than waiting on hold whenever possible.

### Block 4 (14:30 - 16:00): Deep Clinical Writing
* **Goal**: Zero interruptions for high-stakes regulatory documentation.
* Turn phone on "Do Not Disturb" (delegate emergency coverage if possible).
* Batch 30/60/90-day Treatment Plan Reviews using the [[Cheat-Sheets/SMART Goals & Objectives Bank|SMART Goal Bank]] and [[Cheat-Sheets/ASAM Dimensions & Medical Necessity Cheat Sheet|ASAM Cheat Sheet]].
* **Rule of Thumb**: Never write a treatment plan from a blank page. Use the modular template.

### Block 5 (16:00 - 17:00): Continuity of Care & Next-Day Lock-in
* **Goal**: Close the loop so tomorrow runs smoothly.
1. Confirm next-day Medi-Drive reservations (cutoff is typically 48–24 hours in advance).
2. Transmit toxicology or progress updates to OTP/Methadone clinics.
3. Send discharge summaries or step-down referrals for clients finishing PHP/IOP this week.
4. Review the [[00 - Dashboard|Dashboard]] radar for tomorrow's auth deadlines.

---

## 🔄 The Weekly Batching Schedule

Avoid doing every task every day. Batch administrative tasks into dedicated weekly anchors:

| Day | Primary Administrative Batch Task |
| :--- | :--- |
| **Monday** | Audit week’s upcoming UR auth expiration dates; submit early reviews. |
| **Tuesday** | Intensive Treatment Plan Writing Block (batch 3–4 plan updates). |
| **Wednesday** | MAT / Methadone Clinic Coordination (batch send UDS results & attendance to OTPs). |
| **Thursday** | **Medi-Drive Weekly Reservation Lock-in** (Submit all recurring rides for the upcoming week). |
| **Friday** | Discharge planning, step-down coordination, next week census forecasting. |

---

## 🚨 Emergency Standard Operating Procedures (SOPs)

### SOP 1: Medi-Drive (NEMT) No-Show or Late Pickup
1. **Immediate Action**: Call the broker dispatch line directly with:
   * Client Medicaid ID
   * Confirmation / Trip Reservation Number
   * Pickup address and scheduled pickup window
2. **Escalation**: If the driver is more than 30 minutes late, request an **"Urgent Re-route / Will-Call Rescue Ride"** through the supervisor queue.
3. **Documentation**: Log the driver no-show in the [[Trackers/Medi-Drive & Transportation Roster|Transportation Roster]] with timestamp and dispatcher badge number. If client misses clinical group hours due to transit failure, note *“Transportation delay beyond client control”* in attendance record to preserve compliance.

### SOP 2: Methadone / OTP Dosing Crisis
1. **Situation**: Client arrives at PHP/IOP having missed their morning dose, or OTP put a dosing hold due to missing counseling/intake.
2. **Steps**:
   - Verify client’s last dose date/time and milligram dose.
   - Contact the OTP dosing nurse line (found in [[Trackers/MAT & Methadone Coordination Log|MAT Coordination Log]]).
   - Obtain temporary administrative clearance or fax proof of program attendance.
   - If withdrawal symptoms present (COWS $\ge$ 8), consult the medical director / program physician immediately. Do NOT send client home without a documented clinical plan.

### SOP 3: Immediate Denial / Peer-to-Peer Requested
1. Request immediate Peer-to-Peer (P2P) time window within 24–48 hours of adverse determination.
2. Pull the [[Cheat-Sheets/ASAM Dimensions & Medical Necessity Cheat Sheet|ASAM Cheat Sheet]] and pull Dimension 3 (Emotional/Behavioral/Cognitive) and Dimension 5 (Relapse Potential).
3. Brief the reviewing physician/psychiatrist with 3 bullet points:
   * *Recent active triggers/cravings or mental health instability.*
   * *Why Outpatient (OP) level of care has failed or is unsafe.*
   * *Specific clinical goals that will be resolved within the next 5–7 days.*
