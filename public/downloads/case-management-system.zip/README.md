# 🏥 Behavioral Health Case Management Operating System (Obsidian Vault)

A complete, battle-tested operational workspace designed to eliminate administrative burnout for Behavioral Health Case Managers, Intake Coordinators, and IOP/PHP clinical teams.

---

## ⚡ 3-Minute Setup: Getting Started

### Step 1: Install Obsidian (Free)
If you don't already have Obsidian installed:
1. Download Obsidian for Windows or Mac from: **[https://obsidian.md/download](https://obsidian.md/download)**
2. Run the installer (it takes about 15 seconds; no account or sign-in required).

### Step 2: Open This Folder as a Vault
1. Open Obsidian.
2. On the welcome screen, look for **"Open folder as vault"** and click **"Open"**.
3. Browse to this extracted folder (`case-management`) and select it.
4. Obsidian will open with your full sidebar, navigation, and notes ready to go.

### Step 3: Open the Quick-Start Guide
In the left sidebar, click on:
👉 **`START HERE - Quick-Start Guide for Case Managers.md`**  
or  
👉 **`00 - Dashboard.md`**

---

## 🧭 Vault Layout & Directory Guide

* **`00 - Dashboard.md`**: Master command cockpit showing your daily rhythm, 7-day insurance authorization radar, and 30/60/90-day treatment plan review deadlines.
* **`01 - Systems & Daily Cadence.md`**: The 5-block daily time-blocking schedule (protecting morning transit check, client contact, UR window, and clinical writing).
* **`START HERE - Quick-Start Guide for Case Managers.md`**: Friendly, non-technical walkthrough for day-to-day operations.

### 📁 `Templates/`
* `Template - Client Master File.md`: Complete client profile with HIPAA-safe metadata, contacts, transportation schedule, and OTP details.
* `Template - Biopsychosocial Intake Checklist.md`: Rapid 30-minute intake workflow and ASAM 6-dimension assessment.
* `Template - Treatment Plan & Review.md`: Audit-proof Golden Thread treatment plans and 30/60/90-day continued stay reviews.
* `Template - UR Concurrent Review Prep Sheet.md`: 5-minute phone call cheat-sheet for insurance authorizations.
* `Template - Continuity of Care & Discharge Plan.md`: Step-down, warm handoff, and relapse safety plan.

### 📁 `Trackers/`
* `Master Census & Deadline Tracker.md`: Tabular tracker for all active clients, levels of care, and compliance due dates.
* `Medi-Drive & Transportation Roster.md`: Standing ride schedule, broker rolodex (Modivcare, Veyo), and no-show audit logs.
* `MAT & Methadone Coordination Log.md`: Opioid Treatment Program (OTP) directory, dosing windows, and 42 CFR Part 2 ROI tracking.

### 📁 `Cheat-Sheets/`
* `ASAM Dimensions & Medical Necessity Cheat Sheet.md`: Defensible clinical phrases for PHP/IOP continued stay justification.
* `SMART Goals & Objectives Bank.md`: Pre-written measurable objectives for SUD, Depression, Anxiety, MAT, and Housing.
* `De-escalation & Workflow SOPs.md`: Word-for-word phone scripts for late NEMT drivers, OTP dosing hold clearances, and AMA de-escalation.

---

## 🤖 Optional: Automated Handwritten Intake OCR

If you scan paper intake packets or receive handwritten doctor/counselor faxes:
1. Save the scanned PDF into `Incoming-PDFs/`.
2. **100% Local & Offline (HIPAA Private)**:
   * Install [Ollama](https://ollama.com) and run `ollama run llama3.2-vision`.
   * Double-click `Run-Intake-Digitizer-LOCAL.bat`.
3. **Cloud-Assisted (Gemini Vision)**:
   * Add your Google Gemini API key to `.env` (see `.env.example`).
   * Double-click `Run-Intake-Digitizer.bat`.

The script will transcribe the handwriting, generate the client file in `Clients/`, and update your Census and Transportation trackers automatically.
