# Master Case Management Dashboard

> [!TIP]
> **New to this system?** Read the [[START HERE - Quick-Start Guide for Case Managers|🌟 Quick-Start Guide for Case Managers]], [[02 - Why This System Works - Benefits & ROI|💎 Why This System Works (Benefits & ROI)]], and [[Guides/How-to-Digitize-Handwritten-PDFs|📄 How to Digitize Handwritten Intake PDFs]].

> [!IMPORTANT]
> **HIPAA / Confidentiality Best Practice**: Use Client ID / EHR Record # or Initials within filenames and notes. Avoid full names in unencrypted filenames.

---

## 🚨 Critical Daily Action Matrix

```
┌─────────────────────────── Daily Rhythm ───────────────────────────┐
│ 08:30 - 09:30 │ Morning Logistics: Medi-Drive check & MAT holds    │
│ 09:30 - 12:00 │ Client Contact: Intakes, 1-on-1s, IOP/PHP check-in │
│ 13:00 - 14:30 │ Utilization Review: Concurrent reviews & Auths     │
│ 14:30 - 16:00 │ Deep Clinical: Treatment Plans & 30/60/90d Reviews │
│ 16:00 - 17:00 │ Continuity: Transport rosters & OTP updates        │
└────────────────────────────────────────────────────────────────────┘
```

---

## ⚡ Quick Navigation

| Resource | Description | Shortcut |
| :--- | :--- | :--- |
| **Census & Deadlines** | Master list of all active clients & due dates | [[Trackers/Master Census & Deadline Tracker\|Master Census Tracker]] |
| **Medi-Drive Log** | NEMT reservations, broker contacts, ride issues | [[Trackers/Medi-Drive & Transportation Roster\|Medi-Drive Roster]] |
| **MAT / Methadone Log** | OTP clinic contacts, dosing status, ROIs | [[Trackers/MAT & Methadone Coordination Log\|MAT Coordination Log]] |
| **ASAM Cheat Sheet** | Justifications for PHP/IOP medical necessity | [[Cheat-Sheets/ASAM Dimensions & Medical Necessity Cheat Sheet\|ASAM Cheat Sheet]] |
| **SMART Goal Bank** | Pre-written clinical goals & objectives | [[Cheat-Sheets/SMART Goals & Objectives Bank\|SMART Goal Bank]] |
| **Daily Workflow SOPs** | Time-blocking guide & crisis triage | [[01 - Systems & Daily Cadence\|Daily Cadence & SOPs]] |

---

## 📅 Compliance & Deadline Radar

### 1. Utilization Reviews & Authorizations (Due within 7 Days)
*Keep insurance authorizations updated at least 48 hours before expiration.*

| Client ID | Level | Payer / Plan | Auth End Date | Days Left | Status | UR Sheet |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| *Ex: C-1042* | *PHP* | *Aetna BH* | *2026-09-10* | *4 days* | *Prep sent* | *[[Templates/Template - UR Concurrent Review Prep Sheet\|Review Note]]* |
| | | | | | | |
| | | | | | | |

### 2. Treatment Plan Reviews (Due Every 30 / 60 / 90 Days)
*Unsigned or expired plans risk payor audit recoupment.*

| Client ID | Level | Last Tx Plan Date | Next Review Due | Days Left | Primary Focus / Notes |
| :--- | :--- | :--- | :--- | :--- | :--- |
| *Ex: C-1018* | *IOP* | *2026-08-10* | *2026-09-09* | *3 days* | *Step-down evaluation to OP* |
| | | | | | |
| | | | | | |

---

## 🚌 Morning Transport & Logistics Flash (Medi-Drive & MAT)

* **Morning Run-Down Checklist**:
  - [ ] Check email/voicemail for ride cancellations or dispatcher alerts
  - [ ] Verify attendance on morning PHP/IOP roster against transport list
  - [ ] Address any OTP/Methadone dosing holds or guest dosing confirmations
  - [ ] Submit ride modifications for tomorrow by the 2:00 PM cutoff

---

## 📂 New Client Template Quick-Links
When starting a new case or procedure, create a note from:
* [[Templates/Template - Client Master File|Client Master File]]
* [[Templates/Template - Biopsychosocial Intake Checklist|Intake & Biopsychosocial Checklist]]
* [[Templates/Template - Treatment Plan & Review|Treatment Plan & Review Note]]
* [[Templates/Template - UR Concurrent Review Prep Sheet|UR Concurrent Review Prep Sheet]]
* [[Templates/Template - Continuity of Care & Discharge Plan|Discharge & Continuity of Care Plan]]
